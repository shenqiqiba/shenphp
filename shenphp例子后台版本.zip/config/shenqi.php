<?php /*自定义的网站配置文件 神奇blog*/
 return array (
  'title' => '神奇雨',
  'url' => 'http://shenqi.com',
  'keywords' => '神奇雨,神奇blog,神奇cms',
  'apipw' => 'qwerrewq33322',
  'qq' => '97302834',
  'imagesmax' => '3000',
  'filehouzhui' => 'jpg|png|zip|rar',
  'indexhd' => '0',
  'template' => 'shenqi',
  'shenqikai' => '0',
  'titlecf' => '1',
  'description' => '神奇的描述',
  'tongji' => '<script type="text/javascript" src="https://s22.cnzz.com/z_stat.php?id=1273608830&web_id=1273608830"></script>',
  'copyright' => '<p style="text-align: center;" class="shuoming">
            <a href="/about/index.html">关于我们</a>  |
            <a href="/about/contact.html">联系我们</a>  |
            <a href="/about/advertise.html">商务合作</a>  |
            <a href="/about/fazhan.html">发展历程</a>  |
            <a href="/sitemap.html">网站地图</a>  |
            <a href="http://shenqiyu.com/">返回首页</a>
        </p>
        <p style="text-align: center;" class="shuoming">©2018 神奇雨 苏ICP备15044674号-1 <img src=""> 苏公网安备 32050702010397号 </p>',
  'yqm' => '0',
  'comment' => '1',
  'groupqx' => '1',
  'searchkaiguan' => '0',
  'seachjg' => '1',
  'commentjg' => '60',
  'cachekaiguan' => '0',
  'cachelx' => 'file',
  'cachehost' => '{$list.cachehost}',
  'cacheport' => '11211',
  'cacheusername' => '',
  'cachepassword' => '',
  'hcsj' => '3600',
  'articlecache' => '1',
  'pluginscache' => '1',
  'luyoucachesj' => '10',
  'imgys' => '0',
  'ysqiangdu' => '0.5',
  'imgsy' => '1',
  'syweizhi' => '1',
  'wenzisy' => 'shenqiyu.com',
  'zitifont' => '20',
  'syyanse' => '#d11b1b',
);