<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/7  6:32
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\model;



use shenphp\lib\Cookie;
use shenphp\lib\Model;
use shenphp\lib\Session;

class User extends Model
{
    public function Login($user_name,$user_pw,$jizhuwo)
    {
        if(!isset($user_name) || !isset($user_pw)){
            return json(['code'=>1,'msg'=>'请不要使用软件或者屏蔽js!']);
        }
        $db = new Model();
        $userinfo = $db->get('user', '*', ['user_name' => $user_name]);
        if ($userinfo) {
            if(!password_verify($user_pw,$userinfo['user_pw'])){
                return json(['code'=>1,'msg'=>'失败,账号or密码错误']);
            }
            if (intval($userinfo['user_status']) !== 0) {
                return json(['code' => 1, 'msg' => '账号好像冻结啦']);
            }
            if($jizhuwo==1){
                Session::chushihua(36000);
                Cookie::set('user_id', $userinfo['user_id'],36000);
            }else{
                Cookie::set('user_id', $userinfo['user_id'],3600);
            }
            Session::set('user_id', $userinfo['user_id']);
            Session::set('user_name', $userinfo['user_name']);
            if(intval($userinfo['group_id'])==4){
                Session::set('admin', $userinfo['user_id']);//后台管理标志  需要加判断
            }
            return json(['code' => 0, 'msg' => 'ok!登录成功啦!', 'url' =>url('admin/admin/index')]);
        }
        return json(['code'=>1,'msg'=>'失败,账号or密码错误']);

    }

}