<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/20  21:43
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Page;

class Link extends Base
{
    public function linklist(){
        $db=$this->db();
        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $totalItems =$db->count('link');//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/link/linklist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('link','*',['LIMIT'=>[$start,$itemsPerPage]]);
        $this->assign('list',$list);
        $this->assign('page', $paginator);
        return $this->display(ADMIN_VIEW.'link.php');
    }


    public function linkadd(){

        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $param['link_addtime']=time();
            $db=$this->db();
            $res=$db->insert('link',$param)->rowCount();

        }
        if($res>0){
            exit( json(['code'=>0,'msg'=>'添加成功']));
        }
        exit(json(['code'=>1,'msg'=>'添加失败'])) ;
    }

    public function linkedit(){
        $link_id=input('link_id');
        $db=$this->db();
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $links=$db->update('link',$param,['link_id'=>$param['link_id']])->rowCount();

            if($links>0){
                exit(json(['code'=>0,'msg'=>'修改成功']) );
            }
            exit( json(['code'=>1,'msg'=>'修改失败']));
        }
        $links=$db->get('link','*',['link_id'=>$link_id]);
        $this->assign('links', $links);
        return $this->display(ADMIN_VIEW.'linkedit.php');
    }


    public function linkdel(){
        $link_id=input('link_id');
        $db=$this->db();
        if(is_array($link_id)){
            foreach($link_id as $k=>$v){
                $res=$db->delete('link',['link_id'=>$v])->rowCount();
            }
        }else{
            $res=$db->delete('link',['link_id'=>$link_id])->rowCount();
        }
        if($res>0){
            exit(json(['code'=>0,'msg'=>'删除成功'])) ;
        }
        exit(json(['code'=>1,'msg'=>'删除失败'])) ;
    }

}