<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  3:30
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Config;

class Kuozhan extends Base
{
    public function api(){
        $typelist=gettypeTrees();
        $this->assign('typelist', $typelist);
        return $this->display(ADMIN_VIEW.'api.php');
    }

    //模板
    public function muban(){
        $wenjians=scandir(ROOT_PATH.DS.'diy'.DS.'view'.DS.Config::get('shenqi','template').DS);
        $this->assign('muban', $wenjians);
        return $this->display(ADMIN_VIEW.'muban.php');
    }
    //模板编辑
    public function mubanedit(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            file_put_contents(ROOT_PATH.DS.'diy'.DS.'view'.DS.Config::get('shenqi','template').DS.$param['mubanname'],$param['html']);
            exit(json(['code'=>0,'msg'=>'完成编辑'])) ;
        }
        $mubanname=input('mubanname');
        $html=file_get_contents(ROOT_PATH.DS.'diy'.DS.'view'.DS.Config::get('shenqi','template').DS.$mubanname);
        $this->assign('html', $html);
        $this->assign('mubanname', $mubanname);
        return $this->display(ADMIN_VIEW.'mubanedit.php');
    }

    //路由
    public function luyou(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $html=$_POST;
            file_put_contents(ROOT_PATH.DS.'route.php',$html);
            exit(json(['code'=>0,'msg'=>'完成'])) ;
        }
        $route=file_get_contents(ROOT_PATH.DS.'route.php');
        $this->assign('route', $route);
        return $this->display(ADMIN_VIEW.'luyou.php');
    }

    //静态
    public function jingtai(){
        $path=ROOT_PATH.DS.'html'.DS.'zs'.DS;
        if(!is_dir($path)){
            markdirs($path);
        }
        $wenjians=scandir($path);
        $this->assign('wenjians', $wenjians);
        return $this->display(ADMIN_VIEW.'jingtai.php');
    }

    public function jingtaiedit(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            file_put_contents(ROOT_PATH.DS.'html'.DS.'zs'.DS.$param['name'],$param['html']);
            exit(json(['code'=>1,'msg'=>'完成'])) ;
        }
        $name=input('name');
        $wenjians=file_get_contents(ROOT_PATH.DS.'html'.DS.'zs'.DS.$name);
        $this->assign('name', $name);
        $this->assign('html', $wenjians);
        return $this->display(ADMIN_VIEW.'jingtaiedit.php');
    }
    public function jingtaidel(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            @unlink(ROOT_PATH.DS.'html'.DS.'zs'.DS.$param['name']);
            exit(json(['code'=>0,'msg'=>'完成'])) ;
        }
        exit(json(['code'=>1,'msg'=>'????'])) ;
    }

    public function jingtaiadd(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            file_put_contents(ROOT_PATH.DS.'html'.DS.'zs'.DS.$param['name'],$param['html']);
            exit(json(['code'=>0,'msg'=>'完成'])) ;
        }
        return $this->display(ADMIN_VIEW.'jingtaiadd.php');
    }
}