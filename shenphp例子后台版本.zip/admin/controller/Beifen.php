<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  2:52
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use extend\Backup;
use extend\Sql;
use shenphp\lib\Config;
use shenphp\lib\Page;

class Beifen extends Base
{
    public function sqlzhushou(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $sql=$_POST;
            if(empty($sql['sql']) || $sql['sql']==''){
                return json(['code'=>1,'msg'=>'别闹']);
            }
            $db=$this->db();
            $res=$db->query($sql['sql'])->fetchAll();
            //dump($res);
            $res=json($res);
            exit(json(['code'=>0,'msg'=>'操作完毕','text'=>$res])) ;
        }
        return $this->display(ADMIN_VIEW.'sql.php');

    }

    public function biaoadd(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $sqlmodel=new Sql();
            $res=$sqlmodel->addtable($param['table'],$param['comment']);
            exit(json(['code'=>0,'msg'=>'操作完毕'])) ;
        }

    }
    public function biaocaozuo(){
        $table=input('table');
        $type=input('type');
        //1修复 2优化 3删除
        $model=new Sql();;
        if($type==1){
            $res=$model->xiufu($table);

            if($res[0]['Msg_text']=='OK'){
                exit(json(['code'=>0,'msg'=>'修复完成'])) ;
            }else{
                exit(json(['code'=>1,'msg'=>'修复失败'])) ;
            }

        }
        if($type==2){
            $res= $model->youhua($table);
            if($res[0]['Msg_text']=='OK'){
                exit(json(['code'=>0,'msg'=>'优化完成'])) ;
            }else{
                exit(json(['code'=>1,'msg'=>'优化失败'])) ;
            }
        }

        if($type==3){
            $res=$model->del($table);
            exit(json(['code'=>0,'msg'=>'删除完毕'])) ;
        }
    }
    public function biao(){
        $sqlcore=new Sql();
        $list=$sqlcore->gettable();
        $this->assign('list', $list);
        return $this->display(ADMIN_VIEW.'biao.php');
    }

    public function ziduan(){
        $sqlcore=new Sql();
        $table=input('table_name');
        $this->assign('table', $table);
        $ziduan=$sqlcore->tableziduan($table);
        $this->assign('list', $ziduan);
        return $this->display(ADMIN_VIEW.'ziduan.php');
    }
    public function ziduanadd(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $sqlmodel=new Sql();
            $res=$sqlmodel->addziduan($param['table'],$param['Field'],$param['Type'],$param['changdu'],$param['Default'],$param['Comment'],$param['Null']);
            exit(json(['code'=>0,'msg'=>'添加完毕'])) ;
        }
    }
    public function ziduandel(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){

            $param=$_POST;
            $ziduan=$param['ziduan'];
            $table=$param['table'];
            $sqlmodel=new Sql();
            $res=$sqlmodel->delziduan($table,$ziduan);
            exit(json(['code'=>0,'msg'=>'删除完毕']));
        }

    }
    public function beifen(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $beifenpath=ROOT_PATH.DS.'diy'.DS.'backup'.DS;
            $beifenname='shenqi'.date('Y-m-dHis',time()).'sql';
            $filename=$beifenpath.$beifenname;

            $configg=[
                'host' => Config::get('database','server'),
                'port' => Config::get('database','port'),
                'user' =>Config::get('database','username'),
                'password' =>Config::get('database','password'),
                'database' =>Config::get('database','database_name'),
                'charset' =>Config::get('database','charset'),
                //带上路径
                'target' => $filename.'.sql'
            ];

            $qq=new Backup($configg);
            $res=$qq->backup();
            if(!$res){
                exit(json(['code'=>1,'msg'=>$qq->getError()]));
            }
            if($param['bakplace']!==''){
                if(!empty($param['zipbak'])&& $param['zipbak']=='y'){
                    $zipname = $filename.".sql.gz";//压缩文件名
                    $fp = gzopen ($zipname, 'w9');
                    gzwrite ($fp, file_get_contents($filename.".sql"));
                    gzclose($fp);
                    /*
                    $path1= $filename.'.sql';//待压缩文件a
                    $zipname = $filename.".zip";//压缩文件名
                    $zip = new ZipArchive();//初始化压缩对象
                    $zip->open($zipname,ZipArchive::CREATE);   //打开压缩包
                    $zip->addFile($path1,$beifenname.'.sql');   //向压缩包中添加文件 并在zip中重命名
                    $zip->close();  //关闭压缩包
                    */
                    @unlink($filename.".sql");//删除文件
                }
                exit(json(['code'=>0,'msg'=>$qq->getError()])) ;
                //dump($qq->getError());
            }
            exit(json(['code'=>0,'msg'=>$qq->getError()])) ;

        }
        $list=scandir(ROOT_PATH.DS.'diy'.DS.'backup');
        $this->assign('list', $list);
        return $this->display(ADMIN_VIEW.'beifen.php');
    }

    public function del(){
        $name=input('name');
        if($name==''){
            exit(json(['code'=>1,'msg'=>'滚蛋吧'])) ;
        }
        $res=@unlink(ROOT_PATH.DS.'diy'.DS.'backup'.DS.$name);
        if($res){
            exit(json(['code'=>0,'msg'=>'删除成功'])) ;
        }
        exit(json(['code'=>1,'msg'=>'删除失败']));

    }

    public function huanyuan(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $name=$param['name'];
            if($name==''){
                exit(json(['code'=>1,'msg'=>'滚蛋吧'])) ;
            }
            $shujukuname=$name;
            $filename=ROOT_PATH.DS.'diy'.DS.'backup'.DS.$shujukuname;
            $nogz=true;
            if(strpos($shujukuname,".gz")){
                $nogz=false;
                $buffer_size = 4096;
                $out_file_name = str_replace('.gz', '', $filename);
                $file = gzopen($filename, 'rb');
                $out_file = fopen($out_file_name, 'wb');
                $str='';
                while(!gzeof($file)) {
                    fwrite($out_file, gzread($file, $buffer_size));
                }
                fclose($out_file);
                gzclose($file);
                $filename=str_replace('.gz', '', $filename);
            }

            $configg=[
                'host' => Config::get('database','server'),
                'port' => Config::get('database','port'),
                'user' =>Config::get('database','username'),
                'password' =>Config::get('database','password'),
                'database' =>Config::get('database','database_name'),
                'charset' =>Config::get('database','charset'),
                //带上路径
                'target' => $filename.'.sql'
            ];
            $qq=new Backup($configg);
            $res=$qq->restore($filename);
            if($res){
                if(!$nogz){
                    @unlink($filename);
                }
                exit(json(['code'=>0,'msg'=>'还原成功'.$qq->getError()])) ;
            }
            exit(json(['code'=>1,'msg'=>'还原失败'.$qq->getError()])) ;

        }


    }
}