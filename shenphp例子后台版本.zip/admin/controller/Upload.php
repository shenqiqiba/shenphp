<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/20  17:49
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;

use admin\controller;
use shenphp\lib\Config;
use shenphp\lib\Img;
use shenphp\lib\Water;

class Upload extends Base
{
    public function index(){
        $db=$this->db();

        if(!empty($_GET['article_id'])){
            $article_id=$_GET['article_id'];
            $imglist=$db->select('file','*',['article_id'=>$article_id]);
            $this->assign('imglist', $imglist);
        }else{
            $this->assign('imglist', []);
        }

        $this->display(ADMIN_VIEW.'upload.html');
        return;
    }

    public function upload(){


        $param=$_GET;
        if(empty($param['fileid']) && empty($param['type'])){
            exit( json(['code'=>1,'msg'=>'fileid不能为空']));
        }
        if(empty($param['fileid']) ){
            $fileid='';
        }else{
            $fileid=$param['fileid'];
        }
        $linshistr= Config::get('shenqi','filehouzhui');
        $maxsize=Config::get('shenqi','imagesmax')*1024;
        $filehouzhui=explode('|',$linshistr);
        $files=$_FILES['file'];
        /*
        $files["name"];//文件名
        $files["type"];//文件类型
        $files["tmp_name"];//临时数据
        $files["error"];//错误信息
        $files["size"];//大小*/

        if($maxsize<$files["size"]){
            exit( json(['code'=>1,'msg'=>'超过大小限制啦']));
        }
        $houzhui=pathinfo($files["name"],PATHINFO_EXTENSION);
        $yunxu=false;
        foreach($filehouzhui as $k=>$v){
            if($houzhui==$v){
                $yunxu=true;
            }
        }
        if(!$yunxu) {
            exit(json(['code'=>1,'msg'=>'禁止上传此类型文件'])) ;
        }
        //判断当日文件夹是否存在 不存在就创建
        $lujing = ROOT_PATH.DS.'diy'.DS.'upload'.DS.date('Ymd',time()).DS;
        $saveName=md5(rand(100,5000).time()).'.'.$houzhui;//保存路径
        $url=DS.'diy'.DS.'upload'.DS.date('Ymd',time()).DS.$saveName;
        $saveName=$lujing.$saveName;
        if(!is_dir($lujing)){
            mkdir(iconv("UTF-8", "GBK", $lujing),0777,true);
        }
        //参数１：保存的文件
        // 参数２：保存到哪里去
        $aa=move_uploaded_file($files["tmp_name"],$saveName);


        /* UPLOAD_ERR_OK:其值为0，没有错误发生，文件上传成功
         UPLOAD_ERR_INI_SIZE：其值为1，上传的文件超过了php.ini中upload_max_filesize选项限制的值
         UPLOAD_ERR_FORM_SIZE：其值为2，上传的文件超过了HTML表单中MAX_FILE_SIZE选项限制的值
         UPLOAD_ERR_PARTIAL：其值为3，文件只有部分被上传
         UPLOAD_ERR_NOFILE：其值为4，没有选择上传文件
         UPLOAD_ERR_NO_TMP_DIR：其值为6，找不到临时文件夹
         UPLOAD_ERR_CANT_WRITE：其值为7，写入文件失败
         UPLOAD_ERR_EXTENSION：其值为8，上传的文件被PHP扩展程序中断
        1，上传的文件超过了php.ini中upload_max_filesize选项限制的值2，上传的文件超过了HTML表单中MAX_FILE_SIZE选项限制的值3，文件只有部分被上传4，没有选择上传文件6，找不到临时文件夹7，写入文件失败8，上传的文件被PHP扩展程序中断*/
        if(!$aa){
            exit(json(['code'=>1,'msg'=>'出错！错代码:'.$files["error"].'
        错误代码1，上传的文件超过了php.ini中upload_max_filesize选项限制的值。2，上传的文件超过了HTML表单中MAX_FILE_SIZE选项限制的值。3，文件只有部分被上传。4，没有选择上传文件。6，找不到临时文件夹7，写入文件失败。8，上传的文件被PHP扩展程序中断']) );
        }

        //如果是图片进行压缩
        $ispic=isImage($saveName);
        if($ispic && Config::get('shenqi','imgys')==0 && $aa){
            $percent=Config::get('shenqi','ysqiangdu');//压缩比例 1为不压缩 0到1 越小压缩的越厉害
            $imgys=new Img($saveName,$percent);
            //$imgys=new \shenphp\lib\Img($saveName,$percent);
            $img=$imgys->compressImg($saveName);
            //压缩完毕后水印imgsy
            if(Config::get('shenqi','imgsy')==1){
                //文字 $img,$color='#0000FF',$type=0,$pos=0,$font=18,$str='shenqiyu.com'wenzisy
                $water=new Water($saveName,Config::get('shenqi','syyanse'),0,Config::get('shenqi','syweizhi'),Config::get('shenqi','zitifont'),Config::get('shenqi','wenzisy'));
                //$water=new \shenphp\lib\Water($saveName,$GLOBALS['shenqi']['syyanse'],0,$GLOBALS['shenqi']['syweizhi'],$GLOBALS['shenqi']['zitifont'],$GLOBALS['shenqi']['wenzisy']);
                $water->output();
            }
            if(Config::get('shenqi','imgsy')==2){
                //图片
                $water=new Water($saveName,Config::get('shenqi','syyanse'),1,Config::get('shenqi','syweizhi'),Config::get('shenqi','zitifont'),Config::get('shenqi','wenzisy'));
                $water->output();
            }
        }

        if($files["error"]!==0){
            exit(json(['code'=>1,'msg'=>'出错！'.$files["error"].'
         错误代码：1，上传的文件超过了php.ini中upload_max_filesize选项限制的值。2，上传的文件超过了HTML表单中MAX_FILE_SIZE选项限制的值。3，文件只有部分被上传。4，没有选择上传文件。6，找不到临时文件夹7，写入文件失败。8，上传的文件被PHP扩展程序中断']));
        }
        $db=$this->db();
        //file_id,file_name,file_path,file_type,file_jifen,article_id,file_mk
        if(strpos($fileid,"shen")!==false){
            //添加模式
            $db=$this->db();
            $db->insert('file',['file_path'=>$url,'file_type'=>'文章','file_name'=>$files["name"],'file_mk'=>$fileid]);
            $res=$db->id();
            //$res=$db->insert('file',['file_path'=>$url,'file_type'=>'文章','file_name'=>$files["name"],'file_mk'=>$fileid]);
        }else{
            $db->insert('file',['file_path'=>$url,'file_type'=>'文章','file_name'=>$files["name"],'article_id'=>$fileid]);
            $res=$db->id();
            //$res=$db->insert('file',['file_path'=>$url,'file_type'=>'文章','file_name'=>$files["name"],'article_id'=>$fileid]);
        }
        $file_id=$res;

        if($ispic){
            $ext='pic';
        }else{
            $ext=$houzhui;
        }

        exit(json(['code'=>0,'msg'=>'上传成功','url'=>$url,'ext'=>$ext,'filename'=>$files["name"],'file_id'=>$file_id])) ;




    }


    public function uploaddel(){
        $param=$_POST;
        if(empty($param['file_id'])){
            exit(json(['code'=>1,'msg'=>'fileid不能为空'])) ;
        }
        if(empty($param['img'])){
            exit(json(['code'=>1,'msg'=>'img不能为空'])) ;
        }
        $file_id=$param['file_id'];
        $db=$this->db();
        $res=$db->delete('file',['file_id'=>$file_id])->rowCount();

        $delimg=str_replace("/","\\",$param['img']);
        @unlink(ROOT_PATH.$delimg);
        if($res>0){
            exit(json(['code'=>0,'msg'=>'删除成功']));
        }
        exit(json(['code'=>1,'msg'=>'删除失败']));

    }

}