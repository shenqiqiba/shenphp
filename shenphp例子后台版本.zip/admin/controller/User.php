<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  1:41
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Cookie;
use shenphp\lib\Page;
use shenphp\lib\Session;
use shenphp\lib\Validate;


class User extends Base
{
    public function logout(){
        Session::set('admin','yes');
        Session::set('user_name',null);
        Cookie::set('user_name',null);
        Cookie::set('admin',null);
        exit('正在退出');

    }
    public function useredit(){
        $user_id=input('user_id');
        $db=$this->db();
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $param['user_vipendtime']=strtotime($param['user_vipendtime']);
            if($param['user_pw']==''){
                unset($param['user_pw']);
            }else{
                $param['user_pw']=password_hash($param['user_pw'],PASSWORD_BCRYPT);
            }
            //开始验证
           if($db->count('user','*',['user_name'=>$param['user_name'],'user_id[!]'=>$user_id])>=1){
                exit(json(['code'=>1,'msg'=>'用户名已存在']));
           }
            $validate=new Validate();
            $rule=['user_name|用户名'=>'isEmpty,max|20','user_email|邮箱'=>'isEmpty,isEmail'];
            if(!$validate->yanZheng($param,$rule)){
                exit(json(['code'=>1,'msg'=>$validate::$error]));
            }

            $res=$db->update('user',$param,['user_id'=>$user_id])->rowCount();
            if($res>0){
                exit(json(['code'=>0,'msg'=>'编辑成功'])) ;
            }
            exit(json(['code'=>1,'msg'=>'编辑失败'])) ;


        }
        $userinfo=$db->get('user','*',['user_id'=>$user_id]);
        $this->assign('user', $userinfo);
        $list=getgroupTrees();
        $this->assign('list', $list);
        return $this->display(ADMIN_VIEW.'useredit.php');
    }
    public function useradd(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $param['user_regtime']=time();
            $param['user_viptime']=time();
            $param['user_vipendtime']=time();

            $param['user_pw']=password_hash($param['user_pw'],PASSWORD_BCRYPT);
            //开始验证
            $validate=new Validate();
            $rule=['user_name|用户名'=>'isEmpty,unique:user,max|20','user_pw|密码'=>'isEmpty','user_email|邮箱'=>'isEmpty,isEmail,unique:user'];
            if(!$validate->yanZheng($param,$rule)){
                exit(json(['code'=>1,'msg'=>$validate::$error]));
            }
            $db=$this->db();
            $res=$db->insert('user',$param)->rowCount();

            if($res>0){
                exit(json(['code'=>0,'msg'=>'添加成功'])) ;
            }
            exit(json(['code'=>1,'msg'=>'添加失败'])) ;
        }
        $list=getgroupTrees();
        $this->assign('grouplist', $list);
        $this->display(ADMIN_VIEW.'useradd.php');
    }
    public function userdel(){
        $user_id=input('user_id');
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $db=$this->db();
            $res=$db->delete('user',['user_id'=>$user_id])->rowCount();
            if($res>0){
                exit(json(['code'=>0,'msg'=>'删除成功']));
            }
            exit(json(['code'=>1,'msg'=>'删除失败']));
        }
    }
    public function usershenhe(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $user_status=input('user_status');
            $user_id=input('user_id');
            if($user_status==0){
                $user_status=1;
            }else{
                $user_status=0;
            }
            $db=$this->db();
            $res=$db->update('user',['user_status'=>$user_status],['user_id'=>$user_id])->rowCount();
            if($res>0){
                exit(json(['code'=>0,'msg'=>'操作成功']));
            }
            exit(json(['code'=>1,'msg'=>'操作失败']));
        }
    }

    public function userlist(){
        $db=$this->db();
        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $totalItems =$db->count('user');//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/user/userlist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('user','*',['LIMIT'=>[$start,$itemsPerPage],'ORDER'=>['user_id'=>'DESC']]);

        $this->assign('list',$list);
        $this->assign('page', $paginator);
        $this->display(ADMIN_VIEW.'user.php');
    }
}