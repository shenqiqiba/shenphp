<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/19  19:45
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;


use admin\model\User;
use shenphp\lib\Config;
use shenphp\lib\Db;
use shenphp\lib\Shenphp;

class Login extends Shenphp
{
    public function login(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){

            $db=new Db(Config::all('database'));
            $user_name = isset($_POST['user_name']) ? addslashes(trim($_POST['user_name'])) : '';
            $user_pw = isset($_POST['user_pw']) ? addslashes(trim($_POST['user_pw'])) : '';
            $sq=isset($_POST['sq']) ? addslashes(trim($_POST['sq'])) : '0';
            $usermodel=new User();
            $res=$usermodel->Login($user_name,$user_pw,$sq);
            exit($res);
            return;
        }

        $this->display(ADMIN_VIEW.'login.php');
    }

}