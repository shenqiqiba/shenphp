<?php

/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/19  19:44
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */
namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Cache;
use shenphp\lib\Config;

class Admin extends Base
{
    public function __construct()
    {
        parent::__construct();
    }
    public function index(){
        $this->display(ADMIN_VIEW.'index.php');
    }

    public function welcome(){
        $this->display(ADMIN_VIEW.'welcome.php');
    }

    public function seting(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            $data=$param;
            $cachetxt="
<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/18  0:06
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */
return[
    'type'=>'".$data['cachelx']."',
    'path'=>ROOT_PATH.'/runtime/cache/',
    'time'=>".$data['hcsj'].",
    'prefix'=>'shenqi',
];
";
            $file=ROOT_PATH.DS."config/cache.php";
            $res=file_put_contents($file,$cachetxt);


            $file=ROOT_PATH.DS."config/shenqi.php";
            $data = "<?php /*自定义的网站配置文件 神奇blog*/\n return ".var_export($param,true).";";
            $res=file_put_contents($file,$data);
            if($res){
                 exit(json(['code'=>0,'msg'=>'编辑成功']));
                return;
            }else{
                exit(json(['code'=>1,'msg'=>'编辑失败']));
                return ;
            }
        }
        $results = scandir(ROOT_PATH.DS.'diy'.DS.'view'.DS);
        $templates = [];
        foreach ($results as $name) {
            if ($name === '.' or $name === '..')
                continue;
            if (is_file(ROOT_PATH.DS.'diy'.DS.'view'.DS. $name))
                continue;
            $templates[] = $name;
        }

        $this->assign('templates',$templates);

        $list=Config::all('shenqi');
        $this->assign('list',$list);
        $this->display(ADMIN_VIEW.'seting.php');
    }

    //删除缓存文件
    public function clearcache(){
        Cache::clear();
        exit('清除成功');

    }

    public function  about(){

        return $this->display(ADMIN_VIEW.'about.html');
    }
}