<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  2:41
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Page;

class File extends Base
{
    public function filelist(){
        $db=$this->db();
        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $totalItems =$db->count('file');//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/file/filelist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('file','*',['LIMIT'=>[$start,$itemsPerPage]]);
        $this->assign('list', $list);
        $this->assign('page', $paginator);

        return $this->display(ADMIN_VIEW.'file.php');
    }

    public function filedel(){

        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            if(!empty($param['file_id'])){
                $db=$this->db();
                if(is_array($param['file_id'])){
                    foreach($param['file_id'] as $k=>$v){
                        $res=$db->delete('file',['file_id'=>$v])->rowCount();
                        @unlink(ROOT_PATH.$_POST['file_path']);
                    }
                    if($res>0){
                        exit(json(['code'=>0,'msg'=>'删除成功'])) ;
                    }

                }else{
                    $res=$db->delete('file',['file_id'=>$param['file_id']])->rowCount();
                    if($res>0){
                        @unlink(ROOT_PATH.$_POST['file_path']);
                        exit(json(['code'=>0,'msg'=>'删除成功']));
                    }
                }
                exit(json(['code'=>1,'msg'=>'删除失败']));
            }
        }
    }
}