<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/20  2:27
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Cache;
use shenphp\lib\Config;
use shenphp\lib\Db;

class Type extends Base
{
    private $database;

    public function typelist()
    {

        $this->database = Config::all('database');
        $list = gettypeTrees();
        $this->assign('list', $list);
        $this->display(ADMIN_VIEW . 'type.php');
    }

    public function typedel()
    {
        $type_id = $_POST['type_id'];
        $db = $this->db();
        if (is_array($type_id)) {
            foreach ($type_id as $k => $v) {
                if ($db->count('type', '*', ['type_pid' => $v]) > 0) {
                    exit(json(['code' => 1, 'msg' => '请先删除子分类']));
                } else {
                    $res = $db->delete('type', ['type_id' => $v])->rowCount();
                }
            }
        } else {
            if ($db->count('type', '*', ['type_pid' => $type_id]) > 0) {
                exit(json(['code' => 1, 'msg' => '请先删除子分类']));
            }
            $res = $db->delete('type', ['type_id' => $type_id])->rowCount();
        }

        if ($res) {
            Cache::del("typelistTree");
            exit(json(['code' => 0, 'msg' => '删除成功']));
        }
        exit(json(['code' => 2, 'msg' => '删除失败']));
    }

    public function typeadd(){
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $param=$_POST;
            $db = $this->db();
            $res=$db->insert('type',$param)->rowCount();
            if($res){
                Cache::del("typelistTree");
                exit( json(['code'=>0,'msg'=>'成功君：添加成功咯!!']));
            }else{
                exit( json(['code'=>1,'msg'=>'失败君：添加失败咯!!']));
            }
        }

        $typelist=gettypeTrees();
        $this->assign('list',$typelist);
        $this->display(ADMIN_VIEW . 'typeadd.php');
    }

    public function typeedit()
    {

        $db = $this->db();
        if ($_SERVER['REQUEST_METHOD']=='POST') {
            $param=$_POST;
            $res=$db->update('type',$param,['type_id'=>$param['type_id']])->rowCount();
            if ($res) {
                Cache::del("typelistTree");
                exit(json(['code' => 0, 'msg' => '成功君：修改成功咯!!']));
            }
            exit(json(['code' => 1, 'msg' => '失败君：修改失败o(╯□╰)o!!']));

        }
        $type_id = $_GET['type_id'];
        $type=$db->get('type','*',['type_id'=>$type_id]);
        $this->assign('type', $type);
        $typelist = gettypeTrees();
        $this->assign('list', $typelist);
       return $this->display(ADMIN_VIEW . 'typeedit.php');
    }



}
