<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  2:23
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Page;

class Comment  extends Base
{
    public function commentlist(){
        $db=$this->db();
        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $totalItems =$db->count('comment');//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/comment/commentlist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('comment','*',['LIMIT'=>[$start,$itemsPerPage]]);
        $this->assign('list', $list);
        $this->assign('page', $paginator);

        return $this->display(ADMIN_VIEW.'comment.php');
    }

    public function commentdel(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $comment_id=input('comment_id');
            $db=$this->db();
            if(is_array($comment_id)){
                foreach($comment_id as $k=>$v){
                    $res=$db->delete('comment',['comment_id'=>$v])->rowCount();
                }
            }else{
                $res=$db->delete('comment',['comment_id'=>$comment_id])->rowCount();
            }

            if($res>0){
                exit(json(['code'=>0,'msg'=>'删除成功'])) ;
            }
            exit(json(['code'=>1,'msg'=>'删除失败'])) ;
        }
    }

    public function commentshenhe(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $comment_id=input('comment_id');
            $comment_status=input('comment_status');
            if($comment_status==0){
                $comment_status=1;
            }else{
                $comment_status=0;
            }
            $db=$this->db();
            $res=$db->update('comment',['comment_status'=>$comment_status],['comment_id'=>$comment_id])->rowCount();
            if($res>0){
                exit(json(['code'=>0,'msg'=>'操作成功'])) ;
            }
            exit(['code'=>1,'msg'=>'操作失败']);

        }
    }
}