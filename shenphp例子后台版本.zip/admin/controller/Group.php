<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  2:12
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Cache;

class Group extends Base
{
    public function grouplist(){
        $db=$this->db();

        $list=$db->select('group','*');

        $this->assign('list', $list);
        $typelist=gettypeTrees();
        $this->assign('typelist', $typelist);
        return $this->display(ADMIN_VIEW.'group.php');
    }

    public function groupadd(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;
            if(!empty($param['group_type'])){
                $linshi=',0,';
                foreach($param['group_type'] as$k=>$v){
                    $linshi=$linshi.$v.',';
                }
                unset($param['group_type']);
                $param['group_type']=$linshi;
            }

            if(!empty($param['group_auth'])){
                $linshi='';
                foreach($param['group_auth'] as$k=>$v){
                    $linshi=$linshi.$v.',';
                }
                unset($param['group_auth']);
                $param['group_auth']=$linshi;
            }
            $db=$this->db();
            $res=$db->insert('group',$param)->rowCount();
            if($res>0){
                Cache::del("grouplistTree");
                exit(json(['code'=>0,'msg'=>'添加成功'])) ;
            }
            exit(json(['code'=>1,'msg'=>'添加失败']));

        }
    }

    public function groupedit(){
        $group_id=input('group_id');
        $db=$this->db();
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $param=$_POST;

            if(!empty($param['group_type'])){
                $linshi=',0,';
                foreach($param['group_type'] as$k=>$v){
                    $linshi=$linshi.$v.',';
                }
                unset($param['group_type']);
                $param['group_type']=$linshi;
            }else{
                $param['group_type']='';
            }

            if(!empty($param['group_auth'])){
                $linshi='';
                foreach($param['group_auth'] as$k=>$v){
                    $linshi=$linshi.$v.',';
                }
                unset($param['group_auth']);
                $param['group_auth']=$linshi;
            }else{
                $param['group_auth']='';
            }
            $res=$db->update('group',$param,['group_id'=>$group_id])->rowCount();
            if($res>0){
                Cache::del("grouplistTree");
                exit(json(['code'=>0,'msg'=>'修改成功'])) ;
            }
            exit( json(['code'=>1,'msg'=>'修改失败']));

        }
        $group=$db->get('group','*',['group_id'=>$group_id]);
        $typelist=gettypeTrees();
        $this->assign('typelist', $typelist);
        $this->assign('group', $group);
        return $this->display(ADMIN_VIEW.'groupedit.php');
    }

    public function groupdel(){
        $group_id=input('group_id');
        $db=$this->db();
        $res=$db->delete('group',['group_id'=>$group_id])->rowCount();
        if($res>0){
            Cache::del("grouplistTree");
            exit(json(['code'=>0,'msg'=>'删除成功'])) ;
        }
        exit(json(['code'=>1,'msg'=>'删除失败'])) ;
    }
}