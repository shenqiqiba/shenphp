<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/20  1:55
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Db;
use shenphp\lib\Config;
class Navi extends Base
{

    public function navilist(){

        $list=getnaviTrees();
        $typelist=gettypeTrees();
        $this->assign('list',$list);
        $this->assign('typelist',$typelist);
        $this->display(ADMIN_VIEW.'navi.php');
    }
    public function naviadd(){
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $param=$_POST;
            $database=Config::all('database');
            $db=$db=new Db($database);
            $res=$db->insert('navi',$param);
            if($res->rowCount()>0){
                $cache=new \shenphp\lib\Cache();
                $cache->del("navilistTree");
                exit(json(['code'=>0,'msg'=>'添加成功']));
            }
            exit(json(['code'=>1,'msg'=>'添加失败']));
        }
    }

    public function naviedit(){
        $database=Config::all('database');
        $db=$db=new Db($database);

        if($_SERVER['REQUEST_METHOD']=='POST'){
            $param=$_POST;
            $res=$db->update('navi',$param,['navi_id'=>$param['navi_id']]);
            if($res->rowCount()>0){
                $cache=new \shenphp\lib\Cache();
                $cache->del("navilistTree");
                exit(json(['code'=>0,'msg'=>'修改成功']));
            }
            exit(json(['code'=>1,'msg'=>'修改失败']));
        }

        $type=[];
        if(isset($_GET['navi_id'])){
            $navi=$db->get('navi','*',['navi_id'=>$_GET['navi_id']]);
            $typelist=gettypeTrees();
            $this->assign('navi',$navi);
            $this->assign('typelist',$typelist);
            $this->display(ADMIN_VIEW.'naviedit.php');
        }




    }

    public function navixy(){
        $navi_id=$_POST['navi_id'];
        $navi_status=$_POST['navi_status'];
        if($navi_status==0){
            $navi_status=1;
        }else{
            $navi_status=0;
        }
        $database=Config::all('database');
        $db=$db=new Db($database);
        $res=$db->update('navi',['navi_status'=>$navi_status],['navi_id'=>$navi_id]);
        if($res->rowCount()>0){
            $cache=new \shenphp\lib\Cache();
            $cache->del("navilistTree");
            exit(json(['code'=>0,'msg'=>'操作成功']));
        }
        exit(json(['code'=>1,'msg'=>'操作失败']));
    }

    public function navidel(){
        $navi_id=$_GET['navi_id'];
        $database=Config::all('database');
        $db=new Db($database);
        if($db->count('navi','*',['navi_pid'=>$navi_id])){
            exit(json(['code'=>1,'msg'=>'请先删除子导航']));
        }
        $res=$db->delete('navi',['navi_id'=>$navi_id]);
        if($res->rowCount()>0){
            $cache=new \shenphp\lib\Cache();
            $cache->del("navilistTree");
            exit(json(['code'=>0,'msg'=>'删除成功']));
        }
        exit(json(['code'=>1,'msg'=>'删除失败']));
    }

    public function navipldel(){
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $param=$_POST;
            $database=Config::all('database');
            $db=new Db($database);
            foreach($param['navi_id'] as $k=>$v){
                if($db->count('navi','*',['navi_pid'=>$v])){
                    exit(json(['code'=>1,'msg'=>'请先删除子导航']));
                }
                $res=$db->delete('navi',['navi_id'=>$v]);
            }

            if($res->rowCount()>0){
                $cache=new \shenphp\lib\Cache();
                $cache->del("navilistTree");
                exit(json(['code'=>0,'msg'=>'删除成功']));
            }
            exit(json(['code'=>1,'msg'=>'删除失败']));
        }
    }
}