<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/20  17:06
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;

use admin\controller;
use shenphp\lib\Config;
use shenphp\lib\Page;
use shenphp\lib\Validate;

class Article extends Base
{
    public function articlelist(){

        $db=$this->db();
        if(isset($_GET['page'])){
            $page=$_GET['page'];
        }else{
            $page=1;
        }
        $totalItems =$db->count('article');//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/article/articlelist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);


        $list=$db->select('article','*',['article_status'=>0,'article_type'=>'blog','LIMIT'=>[$start,$itemsPerPage],"ORDER" => ["article_top" => "DESC",'article_typetop'=>'DESC','article_addtime'=>'DESC']]);
        //$list=$model::where('article_status',0)->where('article_type','blog')->order('article_top desc,article_typetop desc,article_addtime desc')->paginate(15);
        //$page = $list->render();
        $this->assign('page', $paginator);
        $this->assign('list', $list);
        $this->display(ADMIN_VIEW . 'article.html');
        return ;

    }

    public function articlesearch(){
        $db=$this->db();
        $keywords=input('keywords');
        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }

        $totalItems =$db->count('article','','',['article_type'=>'blog','article_status'=>0,'article_title[~]'=>$keywords]);//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/article/articlesearch',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);


        $list=$db->select('article','*',['article_type'=>'blog','article_status'=>0,'article_title[~]'=>$keywords]);

        //$list=Db::name('article')->where('article_status',0)->where('article_title','like','%'.$keywords.'%')->order('article_top desc,article_typetop desc,article_addtime desc')->paginate(15);
        //$page = $list->render();
        $this->assign('page', $paginator);
        $this->assign('list', $list);
        $this->display(ADMIN_VIEW.'article.html');
       // return $this->fetch('admin@html/article');
    }

    public function articlelistcaogao(){
        $db=$this->db();

        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $totalItems =$db->count('article','','',['article_status'=>1]);//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/article/articlelistcaogao',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('article','*',['article_status'=>1,'LIMIT'=>[$start,$itemsPerPage],'ORDER'=>['article_top'=>'DESC','article_typetop'=>'DESC','article_addtime'=>'DESC']]);
        //$list=$model::where('article_status',1)->order('article_top desc,article_typetop desc,article_addtime desc')->paginate(15);

        $this->assign('page', $paginator);
        $this->assign('list', $list);
        $this->display(ADMIN_VIEW.'article.html');
    }

    public function articleord(){
        $db=$this->db();
        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $type_id=input('type_id');
        $totalItems =$db->count('article','','',['article_type'=>'blog','article_status'=>0,'type_id'=>$type_id]);//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/article/articlelist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('article','*',['article_status'=>0,'type_id'=>$type_id,'article_type'=>'blog','LIMIT'=>[$start,$itemsPerPage],"ORDER" => ["article_top" => "DESC",'article_typetop'=>'DESC','article_addtime'=>'DESC']]);
        $this->assign('page', $paginator);
        $this->assign('list', $list);
        $this->display(ADMIN_VIEW . 'article.html');
    }
    public function articleedit(){

        $article_id=input('article_id');

        $db=$this->db();
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $data=input();
            $param['article_id']=$data['article_id'];
            $param['article_title']=$data['article_title'];
            $param['article_content']=$data['article_content'];
            $param['article_tag']=$data['article_tag'];
            $param['type_id']=$data['type_id'];
            $param['article_tname']=$data['article_tname'];
            $param['article_password']=$data['article_password'];
            $param['user_name']=$data['user_name'];
            if(isset($data['article_status'])):$param['article_status']=$data['article_status'];endif;
            if(isset($data['article_top'])):$param['article_top']=$data['article_top'];endif;
            if(isset($data['article_ispl'])):$param['article_ispl']=$data['article_ispl'];endif;
            if(isset($data['article_type'])):$param['article_type']=$data['article_type'];endif;
            if(isset($data['article_typetop'])):$param['article_typetop']=$data['article_typetop'];endif;

            $param['article_addtime']=strtotime($data['article_addtime']);
            $param['article_tag']=str_replace(".",",",$param['article_tag']);
            $param['article_tag']=str_replace("，",",",$param['article_tag']);
            $param['article_tag']=str_replace("|",",",$param['article_tag']);
            $param['article_tag']=str_replace("。",",",$param['article_tag']);
            $param['article_tag']=str_replace(" ",",",$param['article_tag']);
            $param['article_tag']=str_replace("  ",",",$param['article_tag']);
            $param['article_tag']=str_replace(",,",",",$param['article_tag']);

            //开始验证
            if(Config::get('shenqi','titlecf')==1){
                $rule=['article_title|文章标题'=>'isEmpty,max|150,unique:article','type_id|分类id'=>'isNum,isEmpty'];
                $validate=new Validate();
                if(!$validate->yanZheng($param)){
                    exit(json(['code'=>2,'msg'=>$validate::$error]));
                    return ;
                }
            }
            //验证完毕

            addhook('admin_savaar',$param);


            /*获取标签对比*/
            $article_tag=$db->get('article','*',['article_id'=>$param['article_id']]);
            /*开始更新*/
            $res=$db->update('article',$param,['article_id'=>$param['article_id']])->rowCount();

            //dump($res);

            /*更新完毕*/
            /*处理自定义字段*/
            $db->delete('diy',['article_id'=>$param['article_id']]);
            if(!empty($data['diy_ziduan'])){
                //article_id,diy_ziduan,diy_val
                foreach($data['diy_ziduan'] as $k=>$v){
                    $db->insert('diy',['article_id'=>$data['article_id'],'diy_ziduan'=>$v,'diy_val'=>$data['diy_val'][$k]]);
                }
            }
            /*处理自定义字段结束*/
            if($res>0){
                if($article_tag!==$param['article_tag']){
                    $tagmap=$db->select('tagmap','*',['article_id'=>$param['article_id']]);
                    foreach($tagmap as$k=>$v){
                        $db->update('tag',['tag_num[-]'=>1],['tag_id'=>$v['tag_id']]);
                    }
                    if($tagmap){
                        $db->delete('tagmap',['article_id'=>$param['article_id']]);
                    }

                    /*添加标签开始*/
                    if($param['article_tag']!==''){
                        $tagarray=explode(',',$param['article_tag']);
                    }else{
                        $tagarray=[];
                    }

                    foreach($tagarray as$k=>$v){
                        $tagjieguo=$db->get('tag','*',['tag_name'=>$v]);
                        if(!$tagjieguo && $v!==''){
                            $db->insert('tag',['tag_name'=>$v,'tag_num'=>1]);
                            $tag_id=$db->id();
                            $db->insert('tagmap',['tag_id'=>$tag_id,'article_id'=>$param['article_id']]);
                        }else{
                            $db->update('tag',['tag_num[+]'=>1],['tag_id'=>$tagjieguo['tag_id']]);
                            $db->insert('tagmap',['tag_id'=>$tagjieguo['tag_id'],'article_id'=>$param['article_id']]);
                        }
                    }
                    /*添加标签结束*/
                }
                exit( json(['code'=>0,'msg'=>'保存成功']) );
            }
            exit(json(['code'=>1,'msg'=>'保存失败'])) ;

        }


        $typelist=gettypeTrees();
        $this->assign('typelist', $typelist);
        $diylist=$db->select('diy','*',['article_id'=>$article_id]);
        $this->assign('diylist', $diylist);
        $this->assign('article_id', $article_id);
        $article=$db->get('article','*',['article_id'=>$article_id]);
        $this->assign('article', $article);
        return $this->display(ADMIN_VIEW.'articleedit.html');

    }



    public function articleadd(){
       $db=$this->db();
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $data= $_POST;
            $param['article_title']=$data['article_title'];
            $param['article_content']=$data['article_content'];
            $param['article_tag']=$data['article_tag'];
            $param['type_id']=$data['type_id'];
            $param['article_tname']=$data['article_tname'];
            $param['article_password']=$data['article_password'];
            $param['user_name']=$data['user_name'];
            if(isset($data['article_status'])):$param['article_status']=$data['article_status'];endif;
            if(isset($data['article_top'])):$param['article_top']=$data['article_top'];endif;
            if(isset($data['article_ispl'])):$param['article_ispl']=$data['article_ispl'];endif;
            if(isset($data['article_type'])):$param['article_type']=$data['article_type'];endif;
            if(isset($data['article_type'])):$param['article_typetop']=$data['article_typetop'];endif;

            $param['article_addtime']=strtotime($data['article_addtime']);

            //开始验证

            if(Config::get('shenqi','titlecf')==1){
                $rule=['article_title|文章标题'=>'isEmpty,max|150,unique:article','type_id|分类id'=>'isNum,isEmpty'];
                $validate=new Validate();
                if(!$validate->yanZheng($param)){
                    exit(json(['code'=>2,'msg'=>$validate::$error]));
                    return ;
                }
            }
            //验证完毕
            $param['article_tag']=str_replace(".",",",$param['article_tag']);
            $param['article_tag']=str_replace("，",",",$param['article_tag']);
            $param['article_tag']=str_replace("|",",",$param['article_tag']);
            $param['article_tag']=str_replace("。",",",$param['article_tag']);
            $param['article_tag']=str_replace(" ",",",$param['article_tag']);
            $param['article_tag']=str_replace("  ",",",$param['article_tag']);
            $param['article_tag']=str_replace(",,",",",$param['article_tag']);
            addhook('admin_savaar',$param);
            $res=$db->insert('article',$param);

            $article_id= $db->id();
            /*处理附件*/
            if(!empty($data['fileid']) && $article_id){
                $db->update('file',['article_id'=>$article_id],['file_mk'=>$data['fileid']]);
            }
            /*处理自定义字段*/
            if(!empty($data['diy_ziduan']) && $article_id){
                //article_id,diy_ziduan,diy_val
                foreach($data['diy_ziduan'] as $k=>$v){
                    $db->insert('diy',['article_id'=>$article_id,'diy_ziduan'=>$v,'diy_val'=>$data['diy_val'][$k]]);
                }
            }
            /*处理标签*/
            if($article_id){
                /*添加标签开始*/
                if($param['article_tag']!==''){
                    $tagarray=explode(',',$param['article_tag']);
                }else{
                    $tagarray=[];
                }

                foreach($tagarray as$k=>$v){
                    $tagjieguo=$db->get('tag','*',['tag_name'=>$v]);
                    if(!$tagjieguo && $v!==''){
                        $db->insert('tag',['tag_name'=>$v,'tag_num'=>1]);
                        $tag_id=$db->id();
                        $db->insert('tagmap',['tag_id'=>$tag_id,'article_id'=>$article_id]);

                    }else{
                        if($v!==''){
                            $db->update('tag',['tag_num[+]'=>1],['tag_id'=>$tagjieguo['tag_id']]);
                            $db->insert('tagmap',['tag_id'=>$tagjieguo['tag_id'],'article_id'=>$article_id]);
                        }
                    }
                }
            }
            /*添加标签结束*/

            if($article_id){
                exit(json(['code'=>0,'msg'=>'保存成功']));
                return ;
            }else{
                exit(json(['code'=>1,'msg'=>'保存失败']));
                return ;
            }

        }

        $typelist=gettypeTrees();
        $this->assign('typelist', $typelist);
        $this->display(ADMIN_VIEW . 'articleadd.html');
        return ;
    }


    public function articledel(){
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $article_id=input('article_id');
            $db=$this->db();
            foreach($article_id as $k=>$v){
                $res=$db->delete('article',['article_id'=>$v])->rowCount();
                if($res){
                    $tags=$db->select('tagmap','*',['article_id'=>$v]);
                    if($tags){
                        foreach($tags as $kk=>$vv){
                            $db->update('tag',['tag_num[-]'=>1],['tag_id'=>$vv['tag_id']]);
                        }
                    }
                    $db->delete('tagmap',['article_id'=>$v]);
                }
                /*删除自定义预留*/
                $db->delete('diy',['article_id'=>$v]);

                /*删除附件字段*/
                $fliess=$db->select('file','*',['article_id'=>$v]);
                foreach($fliess as $kk=>$vv){
                    @unlink(ROOT_PATH.$vv['file_path']);
                }
                $db->delete('file',['article_id'=>$v]);

            }
            //循环结束
            if($res){
                exit(json(['code'=>0,'msg'=>'删除成功'])) ;
            }else{
                exit(json(['code'=>1,'msg'=>'删除失败']));
            }
        }
    }
}