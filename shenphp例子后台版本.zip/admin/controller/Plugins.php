<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  4:19
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;

class Plugins extends Base
{
    public function index(){
        $plugins=new \extend\Plugins();
        $list=$plugins->getlist();
        $this->assign('list', $list);
        return $this->display(ADMIN_VIEW.'plugin.php');
    }

    public function anzhuang(){
        if(request()->isPost()){
            $plugins=new \shenphp\core\Plugins();
            $param=request()->param();
            $name=$param['name'];
            $type=$param['type'];
            if($type==0){
                $res=$plugins->install($name);
                return $res;
            }else{
                $res=$plugins->uninstall($name);
                return $res;
            }
        }
    }

    public function jihuo(){
        if(request()->isPost()){
            $plugins=new \shenphp\core\Plugins();
            $param=request()->param();
            $name=$param['name'];
            $type=$param['type'];
            if($type==0){
                $res=$plugins->activation($name);
                return $res;
            }else{
                $res=$plugins->close($name);
                return $res;
            }
        }
    }
}