<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/21  2:33
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Page;

class Yqm extends Base
{
    public function yqmlist(){
        $db=$this->db();
        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $totalItems =$db->count('yqm');//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/yqm/yqmlist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('yqm','*',['LIMIT'=>[$start,$itemsPerPage]]);
        $this->assign('list', $list);
        $this->assign('page', $paginator);

        $grouplist=getgroupTrees();

        $this->assign('grouplist', $grouplist);

        return $this->display(ADMIN_VIEW.'yqm.php');
    }

    public function yqmadd(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $db=$this->db();
            $param=$_POST;
            if(empty($param['num'])){
                $param['yqm_addtime']=time();
                if($param['yqm_card']=='' || empty($param['yqm_card'])){
                    exit(json(['code'=>1,'msg'=>'邀请码不能为空']));
                }
                $res=$db->insert('yqm',$param)->rowCount();
            }else{
                $newdata=[];
                for ($i=0; $i < $param['num']; $i++) {
                    $scyqm=substr(md5(1 + rand(1,99)* 0x10000+time()),0,4).'-'.substr(md5(2 + rand(99,999)* 0x10000+time()),0,4).'-'.substr(md5(3 + rand(9,99)* 0x10000+time()),4,4).'-'.substr(md5(4 + rand(1,99)* 0x10000+time()),8,4);
                    $zidata=array('yqm_card'=>$scyqm,'yqm_adduser'=>$param['yqm_adduser'],'yqm_addtime'=>time(),'group_id'=>$param['group_id']);
                    $newdata[]=$zidata;
                }
                $res=$db->insert('yqm',$newdata)->rowCount();
            }

            if($res>0){
                exit(json(['code'=>0,'msg'=>'添加成功']))  ;
            }
            exit(json(['code'=>1,'msg'=>'添加失败']))  ;
        }
    }

    public function yqmdel(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $yqm_id=input('yqm_id');
            $db=$this->db();
            $res=$db->delete('yqm',['yqm_id'=>$yqm_id])->rowCount();
            if($res>0){
                exit( json(['code'=>0,'msg'=>'删除成功']));
            }
            exit(json(['code'=>1,'msg'=>'删除失败'])) ;
        }

    }

    public function yqmshenhe(){
        if($_SERVER["REQUEST_METHOD"]=='POST'){
            $yqm_status=input('yqm_status');
            $yqm_id=input('yqm_id');
            if($yqm_status==1){
                $yqm_status=0;
            }else{
                $yqm_status=1;
            }

            $db=$this->db();
            $res=$db->update('yqm',['yqm_status'=>$yqm_status,'yqm_id'=>$yqm_id],['yqm_id'=>$yqm_id])->rowCount();
            if($res>0){
                exit(json(['code'=>0,'msg'=>'修改成功'])) ;
            }
            exit(json(['code'=>1,'msg'=>'修改失败']));
        }

    }


}