<?php
/**
 * Created by 神奇cms.
 * User: 开发作者：神奇  QQ：97302834  官方网站：http://shenqiyu.com.
 * Date: 2020/3/20  21:33
 *'--------------------------------------------------------
 *'这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 *'不允许对程序代码以任何形式任何目的的再发布。
 *'--------------------------------------------------------
 */

namespace admin\controller;
use admin\controller\Base;
use shenphp\lib\Page;

class Tag extends Base
{
    public function taglist(){
        $db=$this->db();

        if(isset($_GET['page'])){
            $page=input('page');
        }else{
            $page=1;
        }
        $totalItems =$db->count('article','','',['article_status'=>1]);//总条数
        $itemsPerPage = 10;///每页条数
        $currentPage = $page;//当前页数
        $urlPattern = url('admin/tag/taglist',['page'=>'(:num)']);//地址'/admin/article.php?page=(:num)';
        $start=$itemsPerPage*($page-1);
        $paginator=new Page($totalItems, $itemsPerPage, $currentPage, $urlPattern);

        $list=$db->select('tag','*',['LIMIT'=>[$start,$itemsPerPage]]);
        $this->assign('list',$list);
        $this->assign('page', $paginator);
        return $this->display(ADMIN_VIEW.'tag.php');
    }

    public function tagdel(){
        $tagid=input('tag_id');
        $db=$this->db();
        if(is_array($tagid)){
            foreach($tagid as $k=>$v){
                $db->delete('tagmap',['tag_id'=>$v]);
                $res=$db->delete('tag',['tag_id'=>$v])->rowCount();
            }

        }else{
            $db->delete('tagmap',['tag_id'=>$tagid]);
            $res=$db->delete('tag',['tag_id'=>$tagid])->rowCount();
        }
        if($res>0){
            exit(json(['code'=>0,'msg'=>'删除成功']) );
        }
        exit(json(['code'=>1,'msg'=>'删除失败'])) ;
    }
}