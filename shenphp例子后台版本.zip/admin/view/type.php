<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
<!-- ace settings handler -->
<script src="/static/js/jquery.min.js"></script>

<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">分类管理</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">

        <!--内容开始-->

        <div class="row">

            <div class="col-xs-12">
                <div class="clearfix">
                    <button type="button" tooltip="添加" class="btn btn-sm btn-primary" onclick="javascript:window.location.href = '<?php echo url('admin/type/typeadd') ?>'"> <i class="fa fa-plus"></i> 添加</button>
                    <button type="button" tooltip="批量删除" class="btn btn-sm btn-danger" onclick="pldel()"> <i class="fa fa-times"></i> 批量删除</button>
                    <button type="button" tooltip="CSV" class="btn btn-sm btn-primary btn-addon" onclick="dccsv()"> <i class="fa fa-download"></i> CSV</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dcxls()"> <i class="fa fa-pencil-square-o"></i> exvel</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dccsv()"> <i class="fa fa-print"></i> 打印</button>
                    共有<?php echo count($list); ?>条数据

                </div>
                <form method="post" id='form'>
                    <table id="simple-table" class="table  table-bordered table-hover">
                        <thead>
                        <tr>
                            <th class="center">
                                <label class="pos-rel"><input type="checkbox" id="shenqi" class="ace"><span class="lbl"></span></label>
                            </th>
                            <th class="detail-col">序号</th>
                            <th>名称</th>
                            <th>描述</th>
                            <th class="hidden-480">别名</th>
                            <th class="hidden-480">模板</th>
                            <th class="hidden-480">查看</th>
                            <th class="hidden-480">文章</th>
                            <th>操作</th>
                        </tr>
                        </thead>

                        <tbody>


                        <?php foreach($list as$k=>$v): ?>

                            <tr>
                                <td class="center"><label class="pos-rel"><input type="checkbox" name="type_id[]" value="<?php echo $v['type_id'] ?>" class="ace"><span class="lbl"></span></label></td>
                                <td><?php echo $v['type_sort'] ?></td>
                                <td ><?php if($v['level']!==0):echo '|'; endif; echo str_repeat('-', $v['level']*4) ?><a href="<?php echo url('admin/type/index',array('type_id'=>$v['type_id'])) ?>" target="_blank"><?php echo $v['type_name'] ?></a> </td>
                                <td class="hidden-480"><?php echo $v['type_des'] ?></td>
                                <td><?php echo $v['type_tname'] ?></td>
                                <td class="hidden-480"><?php echo $v['type_template'] ?></td>
                                <td class="hidden-480"><a>查看</a></td>
                                <td class="hidden-480">0</td>

                                <td>

                                    <div class="hidden-sm hidden-xs btn-group">
                                        <a href="<?php echo url('admin/type/typeedit',['type_id'=>$v['type_id']]) ?>" class="btn btn-xs btn-info"><i class="ace-icon fa fa-pencil bigger-120"></i>编辑</a>
                                        <a href="javascript:;" onclick="del(this,<?php echo $v['type_id']; ?>)" class="btn btn-xs btn-danger"><i class="ace-icon fa fa-trash-o bigger-120"></i>删除</a>

                                    </div>
                                </td>

                            </tr>
                        <?php endforeach; ?>





                        </tbody>
                    </table>
                </form>

            </div><!-- /.span -->
        </div>
        <!--保存按钮-->
        <div align="center">
        </div>

        <button type="button" onclick="login()" class="btn btn-primary">保存信息</button>



        <!--内容结束-->
    </div>
    <!--内容页结束-->

</div><!-- /.page-content -->


<script type="text/javascript">

    function login() {
        $.ajax({
//几个参数需要注意一下
            type: "POST",//方法类型
            dataType: "json",//预期服务器返回的数据类型
            url: "<?php echo url('admin/seting0') ?>" ,//url
            data: $('#form').serialize(),
            success: function (result) {
                console.log(result);//打印服务端返回的数据(调试用)
                if (result.code == 0) {
                    alert(result.msg);
                }else{
                    alert(result.msg);
                }

            }
        });
    }

    /*用户-删除*/
    function del(obj,id){
        if(window.confirm('确认要删除吗？'))
        {
//发异步删除数据
            $.ajax({
                url: "<?php echo url('admin/type/typedel') ?>" ,
                data: {'type_id':id} ,
                type: "post" ,
                dataType:'json',
                success:function(data){
                    if(data.code==0){
                        //$(obj).parents("tr").remove();
                        alert(data.msg);
                        location.reload();
                    }else{
                        alert(data.msg);
                    }}
            })
            alert(data.msg);
        }
    }


    function pldel()
    {
        if(window.confirm('确认要删除吗？')){
            var shuju=$('#form').serialize();
            $.ajax({
                //几个参数需要注意一下
                type: "POST",//方法类型
                dataType: "json",//预期服务器返回的数据类型
                url: "<?php echo url('admin/type/typedel') ?>" ,//url
                data:shuju,
                success: function (result) {
                    console.log(result);//打印服务端返回的数据(调试用)
                    if (result.code == 0) {
                        alert(result.msg);
                        window.location.reload();
                    }else{
                        alert(result.msg);
                        //window.location.reload();//false
                    }
                }
            });}
    }

    jQuery('#simple-table #shenqi').change(function () {
        var set = $(".ace");
        var checked = jQuery(this).is(":checked");
        jQuery(set).each(function () {
            if (checked) {
                $(this).prop("checked", true);
                $(this).parents('tr').addClass("active");
            } else {
                $(this).prop("checked", false);
                $(this).parents('tr').removeClass("active");
            }
        });

    });

    //导出
    function dccsv(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/csv;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".csv");
        link.click();
    }

    function dcxls(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/xls;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".xls");
        link.click();
    }
</script>