<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">插件管理</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">

        <!--内容开始-->

        <div class="row">

            <div class="col-xs-12">
                <div class="clearfix">
                    <button type="button" tooltip="CSV" class="btn btn-sm btn-primary btn-addon" onclick="dccsv()"> <i class="fa fa-download"></i> CSV</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dcxls()"> <i class="fa fa-pencil-square-o"></i> exvel</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dccsv()"> <i class="fa fa-print"></i> 打印</button>
                    共有{$list|count}条数据

                </div>
                <form method="post" id='form'>
                    <table id="simple-table" class="table  table-bordered table-hover">
                        <thead>
                        <tr>
                            <th class="center">
                                <label class="pos-rel"><input type="checkbox" id="shenqi" class="ace"><span class="lbl"></span></label>
                            </th>
                            <th class="detail-col">序号</th>
                            <th>中文名</th>
                            <th>插件名</th>
                            <th>介绍</th>
                            <th>作者</th>
                            <th>发布时间</th>
                            <th>版本</th>
                            <th>状态</th>
                            <th>操作</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $kk=0; ?>
                        <?php foreach($list as $k=>$v): ?>
                            <?php $kk=$kk+1; ?>
                            <tr>

                                <td class="center"><label class="pos-rel"><input type="checkbox" name="id[]" value="<?php echo $kk; ?>" class="ace"><span class="lbl"></span></label></td>
                                <td><?php echo $kk; ?></td>
                                <td><?php echo $v['title']; ?></td>
                                <td><?php echo $v['name']; ?></td>
                                <td><?php echo $v['des']; ?></td>
                                <td><?php echo $v['author']; ?></td>
                                <td><?php echo $v['time']; ?></td>
                                <td><?php echo $v['version']; ?></td>
                                <td><?php if(!$v['install']): ?>
                                        <font style="color: red">
                                            <a href="javascript:;" onclick="anzhuang(this,'<?php echo $v['name']; ?>',0)" class="btn btn-sm btn-grey" title="点击安装">点击安装</a></font>
                                    <?php else: ?>
                                        <a href="javascript:;" onclick="anzhuang(this,'<?php echo $v['name']; ?>',1)" class="btn btn-sm btn-success" title="点击卸载">点击卸载</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(!$v['activation']): ?>
                                        <font style="color: red">
                                            <a href="javascript:;" onclick="jihuo(this,'<?php echo $v['name']; ?>',0)" class="btn btn-sm btn-grey" title="点击激活">点击激活</a></font>
                                    <?php else: ?>
                                        <a href="javascript:;" onclick="jihuo(this,'<?php echo $v['name']; ?>',1)" class="btn btn-sm btn-success" title="点击关闭">点击关闭</a>
                                    <?php endif; ?>
                                    <!--a href="javascript:;" onclick="del(this,'<?php echo $v['name']; ?>',3)" class="btn btn-sm btn-danger">删除</a-->
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                </form>

            </div><!-- /.span -->
        </div>
        <!--保存按钮-->


        <!--内容结束-->
    </div>
    <!--内容页结束-->

</div><!-- /.page-content -->

<script src="/static/js/jquery.min.js"></script>
<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
<script type="text/javascript">


    function anzhuang(obj,name,type) {
        if (window.confirm('确认要安装或者卸载吗？')) {
            //发异步删除数据
            $.ajax({
                url: "{:url('plugins/anzhuang')}",
                data: {'name': name,'type':type},
                type: "post",
                dataType: 'json',
                success: function (data) {
                    if (data.code == 0) {
                        alert(data.msg);
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            })
            alert(data.msg);
        }
    }

    function jihuo(obj,name,type) {
        //发异步删除数据
        $.ajax({
            url: "{:url('plugins/jihuo')}",
            data: {'name': name,'type':type},
            type: "post",
            dataType: 'json',
            success: function (data) {
                if (data.code == 0) {
                    alert(data.msg);
                    location.reload();
                } else {
                    alert(data.msg);
                }
            }
        })
        alert(data.msg);
    }
    //导出
    function dccsv(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/csv;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".csv");
        link.click();
    }
    jQuery('#simple-table #shenqi').change(function () {
        var set = $(".ace");
        var checked = jQuery(this).is(":checked");
        jQuery(set).each(function () {
            if (checked) {
                $(this).prop("checked", true);
                $(this).parents('tr').addClass("active");
            } else {
                $(this).prop("checked", false);
                $(this).parents('tr').removeClass("active");
            }
        });

    });
    function dcxls(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/xls;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".xls");
        link.click();
    }
</script>