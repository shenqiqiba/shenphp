
<?php include_once ADMIN_VIEW.'header.php';?>
<!-- 头部结束 -->
<div class="main-content" style="background: url(/static/images/bg.png) repeat #777;">
    <!-- 内容主体区域 -->

    <iframe id="newpage" src="<?php echo url('admin/admin/welcome') ?>" style="width: 100%;height: 90%;padding:0px;min-height:800px;margin-left:0%"></iframe>
</div>

<?php include_once ADMIN_VIEW.'footer.php';?>