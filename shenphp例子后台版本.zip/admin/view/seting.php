<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">网站配置</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">
        <form class="form-horizontal" id="form" role="form" action="" method="post">
            <!--第一个选项卡-->
            <div class="tabbable" id="tabs-425419"> <!-- Only required for left/right tabs -->
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#panel-277608" data-toggle="tab" >基本设置</a></li>
                    <li class=""><a href="#panel-322627" data-toggle="tab" >会员设置</a></li>
                    <li class=""><a href="#panel-322111" data-toggle="tab" >缓存设置</a></li>
                    <li class=""><a href="#panel-322222" data-toggle="tab" >水印设置</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active "  id="panel-277608" >
                        <!--第一个选项卡-->
                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">站点标题</label>
                            <div class="col-sm-6">
                                <input class="form-control" style="background-color: #ffffff;" id="username" value="<?php echo $list['title']; ?>" placeholder="神奇cms后台管理" name="title" required="" type="text">
                            </div>
                            <p class="help-block col-sm-4 red">* 必填</p>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">站点网址</label>
                            <div class="col-sm-6">
                                <input class="form-control" id="password" value="<?php echo $list['url']; ?>" placeholder="https://baidu.com" name="url" required="" type="text">
                            </div>
                            <p class="help-block col-sm-4 red">* 必填</p>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">关键字</label>
                            <div class="col-sm-6">
                                <input class="form-control" id="password" value="<?php echo $list['keywords']; ?>" placeholder="cms,神奇,源码,php" name="keywords" required="" type="text">
                            </div>
                            <p class="help-block col-sm-4 red">* 必填</p>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">API接口密码</label>
                            <div class="col-sm-6">
                                <input class="form-control" id="apipw" value="<?php echo $list['apipw']; ?>" placeholder="cms,神奇,源码,php" name="apipw" required="" type="text">
                            </div>
                            <p class="help-block col-sm-4 red">* 必填</p>
                        </div>


                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">QQ号</label>
                            <div class="col-sm-6">
                                <input class="form-control" id="QQ" value="<?php echo $list['qq']; ?>" placeholder="3600" name="qq" required="" type="text">
                            </div>
                            <p class="help-block col-sm-4 red">* 必填</p>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">上传文件最大(kb)</label>
                            <div class="col-sm-2">
                                <input class="form-control" id="imagesmax" value="<?php echo $list['imagesmax']; ?>" placeholder="1024" name="imagesmax" required="" type="text">
                            </div>
                            <p class="help-block col-sm-4 red">* 必填</p>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">允许上传后缀</label>
                            <div class="col-sm-6">
                                <input class="form-control" id="filehouzhui" value="<?php echo $list['filehouzhui']; ?>" placeholder="jpg|png" name="filehouzhui" required="" type="text">
                            </div>
                            <p class="help-block col-sm-4 red">* 必填</p>
                        </div>

                        <div class="form-group">
                            <label for="logs" class="col-sm-2 control-label no-padding-right">首页幻灯</label>
                            <div class="col-sm-6">
                                <label style="margin-right:15px;">
                                    <input type="radio" name="indexhd" value="0" <?php if($list['indexhd']==0){echo 'checked="checked"'; }; ?>><span class="text">开启</span>
                                </label>

                                <label style="margin-right:15px;">
                                    <input type="radio" name="indexhd" value="1" <?php if($list['indexhd']==1){echo 'checked="checked"'; }; ?> ><span class="text">关闭</span>
                                </label>
                            </div>
                        </div>



                        <div class="form-group">
                            <label for="group_id" class="col-sm-2 control-label no-padding-right">网站模板</label>
                            <div class="col-sm-6">
                                <select name="template" style="width: 100%;">
                                    <?php foreach($templates as $k=>$v): ?>
                                        <option <?php if($list['template']==$v){echo 'selected="selected"';} ?> value="<?php echo $v; ?>"><?php echo $v; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="group_id" class="col-sm-2 control-label no-padding-right">网站开关</label>
                            <div class="col-sm-6">
                                <select name="shenqikai" style="width: 100%;">
                                    <option <?php if($list['shenqikai']==0){echo 'selected="selected"';} ?>  value="0">开启</option>
                                    <option <?php if($list['shenqikai']==1){echo 'selected="selected"';} ?>  value="1">关闭</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="group_id" class="col-sm-2 control-label no-padding-right">文章标题重复</label>
                            <div class="col-sm-6">
                                <select name="titlecf" style="width: 100%;">
                                    <option <?php if($list['titlecf']==0){echo 'selected="selected"';} ?> value="0">允许</option>
                                    <option <?php if($list['titlecf']==1){echo 'selected="selected"';} ?> value="1">禁止</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">网站描述</label>
                            <div class="col-sm-6">
                                <textarea class="form-control" name="description"  placeholder="cms,神奇,源码,php"><?php echo $list['description']; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right">统计代码</label>
                            <div class="col-sm-6">
                                <textarea class="form-control" name="tongji"><?php echo $list['tongji']; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="username" class="col-sm-2 control-label no-padding-right" placeholder="神奇cms">版权信息</label>
                            <div class="col-sm-6">
                                <textarea class="form-control" name="copyright"><?php echo $list['copyright']; ?></textarea>
                            </div>
                        </div>

                        <?php addhook('admin_seting'); ?>

                        <!--div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="button" onclick="login()" class="btn btn-default">保存信息</button>
                            </div>
                        </div-->
        </form>
    </div>
    <!--第一个选项卡结束-->

    <!--第二个选项卡开始会员-->
    <div class="tab-pane" id="panel-322627" >
        <!--开始内容-->


        <div class="form-group">
            <label for="yqm" class="col-sm-2 control-label no-padding-right">邀请码注册</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="yqm" value="0" <?php if($list['yqm']==0){echo 'checked="checked"';} ?>><span class="text">开启</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="yqm" value="1" <?php if($list['yqm']==1){echo 'checked="checked"';} ?>><span class="text">关闭</span>
                </label>
            </div>
        </div>
        <div class="form-group">
            <label for="comment" class="col-sm-2 control-label no-padding-right">审核评论</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="comment" value="0" <?php if($list['comment']==0){echo 'checked="checked"';} ?>><span class="text">审核</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="comment" value="1" <?php if($list['comment']==1){echo 'checked="checked"';} ?>><span class="text">不审核</span>
                </label>
            </div>
        </div>


        <div class="form-group">
            <label for="comment" class="col-sm-2 control-label no-padding-right">开启用户组权限</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="groupqx" value="0" <?php if($list['groupqx']==0){echo 'checked="checked"';} ?>><span class="text">开启</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="groupqx" value="1" <?php if($list['groupqx']==1){echo 'checked="checked"';} ?>><span class="text">关闭</span>
                </label>
            </div>
        </div>

        <div class="form-group">
            <label for="comment" class="col-sm-2 control-label no-padding-right">搜索开关</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="searchkaiguan" value="0" <?php if($list['searchkaiguan']==0){echo 'checked="checked"';} ?>><span class="text">开启</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="searchkaiguan" value="1" <?php if($list['searchkaiguan']==1){echo 'checked="checked"';} ?>><span class="text">关闭</span>
                </label>
            </div>
        </div>


        <div class="form-group">
            <label for="username" class="col-sm-2 control-label no-padding-right">搜索间隔时间</label>
            <div class="col-sm-6">
                <input class="form-control" id="seachjg" value="<?php echo $list['seachjg']; ?>" placeholder="5" name="seachjg" required="" type="text">
            </div>
            <p class="help-block col-sm-4 red">* 必填</p>
        </div>

        <div class="form-group">
            <label for="username" class="col-sm-2 control-label no-padding-right">评论间隔时间</label>
            <div class="col-sm-6">
                <input class="form-control" id="commentjg" value="<?php echo $list['commentjg']; ?>" placeholder="0" name="commentjg" required="" type="text">
            </div>
            <p class="help-block col-sm-4 red">* 必填</p>
        </div>
        <!--结束内容-->
    </div>
    <!--第二个选项卡结束会员-->

    <!--第三个选项卡开始缓存-->
    <div class="tab-pane" id="panel-322111" >

        <div class="form-group">
            <label for="comment" class="col-sm-2 control-label no-padding-right">数据缓存</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="cachekaiguan" value="0"  <?php if($list['cachekaiguan']==0){echo 'checked="checked"';} ?> ><span class="text">开启</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="cachekaiguan" value="1" <?php if($list['cachekaiguan']==1){echo 'checked="checked"';} ?> ><span class="text">关闭</span>
                </label>
            </div>
        </div>

        <div class="form-group" >
            <label for="yqm" class="col-sm-2 control-label no-padding-right">缓存类型</label>
            <div class="col-sm-2" >
                <label style="margin-right:15px;">
                    <input type="radio" id="file" name="cachelx" value="file" <?php if($list['cachelx']=='file'){echo 'checked="checked"';} ?>><span class="text">file</span>
                </label>
                <label style="margin-right:15px;">
                    <input type="radio" id="memcache" name="cachelx" value="memcached" <?php if($list['cachelx']=='memcache'){echo 'checked="checked"';} ?> ><span class="text">memcached</span>
                </label>
                <label style="margin-right:15px;">
                    <input type="radio" id="redis" name="cachelx" value="redis" <?php if($list['cachelx']=='redis'){echo 'checked="checked"';} ?> ><span class="text">redis</span>
                </label>
            </div>
        </div>

        <div class="form-group" style="display:none;" id="rediss">
            <label for="username" class="col-sm-2 control-label no-padding-right">服务器</label>
            <div class="col-sm-6">
                <input class="col-sm-2" type="text" name="cachehost" placeholder="127.0.0.1" value="{$list.cachehost}" >


                <label for="username" class="col-sm-2 control-label no-padding-right" style="width: 8%;">端口</label>
                <input class="col-sm-2" type="text" name="cacheport" placeholder="11211" value="<?php echo $list['cacheport']; ?>" >

                <label for="username" class="col-sm-2 control-label no-padding-right" style="width: 8%;">账号</label>
                <input class="col-sm-2" type="text" name="cacheusername" placeholder="redis使用" value="<?php echo $list['cacheusername']; ?>" >

                <label for="username" class="col-sm-2 control-label no-padding-right" style="width: 8%;">密码</label>
                <input class="col-sm-2" type="text" name="cachepassword" placeholder="redis使用" value="<?php echo $list['cachepassword']; ?>" >
            </div>

        </div>



        <div class="form-group">
            <label for="username" class="col-sm-2 control-label no-padding-right">全局缓存时间（秒）</label>
            <div class="col-sm-6">
                <input class="form-control" id="hcsj" value="<?php echo $list['hcsj']; ?>" placeholder="3600" name="hcsj" required="" type="text">
            </div>
            <p class="help-block col-sm-4 red">* 必填</p>
        </div>


        <div class="form-group">
            <label for="comment" class="col-sm-2 control-label no-padding-right">文章内容缓存</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="articlecache"  value="0" <?php if($list['articlecache']==0){echo 'checked="checked"';} ?>><span class="text">开启</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="articlecache"  value="1" <?php if($list['articlecache']==1){echo 'checked="checked"';} ?> ><span class="text">关闭</span>
                </label>
            </div>
        </div>

        <div class="form-group">
            <label for="comment" class="col-sm-2 control-label no-padding-right">插件缓存(开发和调试插件请关闭)</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="pluginscache"  value="0" <?php if($list['pluginscache']==0){echo 'checked="checked"';} ?>><span class="text">开启</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="pluginscache"  value="1" <?php if($list['pluginscache']==1){echo 'checked="checked"';} ?> ><span class="text">关闭</span>
                </label>
            </div>
        </div>



        <div class="form-group">
            <label for="username" class="col-sm-2 control-label no-padding-right">页面缓存（秒）</label>
            <div class="col-sm-6">
                <input class="form-control" id="luyoucachesj" value="<?php echo $list['luyoucachesj']; ?>" placeholder="3600" name="luyoucachesj" required="" type="text">
            </div>
            <p class="help-block col-sm-4 red">* 必填</p>
        </div>

    </div>
    <!--第三个选项卡结束-->
    <!--第四个选项卡开始水印-->
    <div class="tab-pane" id="panel-322222" >
        <div class="form-group" >
            <label for="yqm" class="col-sm-2 control-label no-padding-right">图片压缩</label>
            <div class="col-sm-2" >
                <label >
                    <input type="radio" name="imgys" value="0" <?php if($list['imgys']==0){echo 'checked="checked"';} ?> ><span class="text">开启</span>
                </label>

                <label >
                    <input type="radio" name="imgys" value="1" <?php if($list['imgys']==1){echo 'checked="checked"';} ?> ><span class="text">关闭</span>
                </label>

                <label >
                    压缩强度(1到0越低压缩越厉害 1不压缩) <input type="text" name="ysqiangdu" placeholder="1" value="<?php echo $list['ysqiangdu']; ?>" >
                </label>

            </div>

            <div class="horizontal-space"></div>
        </div>


        <div class="form-group">
            <label for="yqm" class="col-sm-2 control-label no-padding-right">图片水印</label>
            <div class="col-sm-2" style="width: 15.33333333%;">
                <label style="margin-right:15px;">
                    <input type="radio" name="imgsy" value="0" <?php if($list['imgsy']==0){echo 'checked="checked"';} ?> ><span class="text">关闭</span>
                </label>
                <label style="margin-right:15px;">
                    <input type="radio" name="imgsy" value="1" <?php if($list['imgsy']==1){echo 'checked="checked"';} ?> ><span class="text">文字</span>
                </label>
                <label style="margin-right:15px;">
                    <input type="radio" name="imgsy" value="2" <?php if($list['imgsy']==2){echo 'checked="checked"';} ?> ><span class="text">图片</span>
                </label>
            </div>
        </div>

        <div class="form-group">
            <label for="yqm" class="col-sm-2 control-label no-padding-right">水印位置</label>
            <div class="col-sm-6">
                <label style="margin-right:15px;">
                    <input type="radio" name="syweizhi" value="1"  <?php if($list['imgsy']==1){echo 'checked="checked"';} ?>><span class="text">左上</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="syweizhi" value="3"  <?php if($list['imgsy']==3){echo 'checked="checked"';} ?>><span class="text">右上</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="syweizhi" value="5"  <?php if($list['imgsy']==5){echo 'checked="checked"';} ?>><span class="text">居中</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="syweizhi" value="7"  <?php if($list['imgsy']==7){echo 'checked="checked"';} ?>><span class="text">左下</span>
                </label>

                <label style="margin-right:15px;">
                    <input type="radio" name="syweizhi" value="9"  <?php if($list['imgsy']==9){echo 'checked="checked"';} ?>><span class="text">右下</span>
                </label>
            </div>
        </div>



        <div class="form-group">
            <label for="username" class="col-sm-2 control-label no-padding-right">文字水印[需要汉字 可自行替换字体test.ttf]</label>
            <div class="col-sm-6">
                <input class="form-control" id="wenzisy" value="<?php echo $list['wenzisy']; ?>" placeholder="神奇cms" name="wenzisy" required="" type="text">
            </div>
            <p class="help-block col-sm-4 red">* 图片水印请替换文件</p>
        </div>

        <div class="form-group">
            <label for="username" class="col-sm-2 control-label no-padding-right">文字字体大小</label>
            <div class="col-sm-6">
                <input class="form-control" id="wenzisy" value="<?php echo $list['zitifont']; ?>" placeholder="20" name="zitifont" required="" type="text">
            </div>
            <p class="help-block col-sm-4 red"></p>
        </div>




        <div class="form-group">
            <label for="username" class="col-sm-2 control-label no-padding-right">文字图片颜色</label>
            <div class="col-sm-6">

                <input class="form-control" id="syyanse" value="<?php echo $list['syyanse']; ?>" placeholder="#ffffff" name="syyanse" required="" type="text">
            </div>
            <p class="help-block col-sm-2 red">* 必填</p>
        </div>


    </div>
    <!--第四个选项卡结束-->


    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <button type="button" onclick="login()" class="btn btn-primary">保存信息</button>
        </div>
    </div>
</div>
</div>

<!--大概是选项卡结束吧-->
</div>
<!--内容页结束-->

</div><!-- /.page-content -->

<script src="/static/js/jquery.min.js"></script>
<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

<!-- ace settings handler -->
<script src="/static/bootstrap/js/bootstrap.min.js"></script>
<script src="/static/admin/js/ace-elements.min.js"></script>
<script src="/static/admin/js/ace.min.js"></script>
<link rel="stylesheet" href="/jquery.bigcolorpicker.css'; ?>" />
<script src="/jquery.bigcolorpicker.js'; ?>"></script>

<script type="text/javascript">
    $(function(){
        //1、用法
        $("#syyanse").bigColorpicker("f1","L",10);

        //2、用法
        $("#syyanse").bigColorpicker("f3");

        //3、用法
        $("#syyanse").bigColorpicker(function(el,color){
            $(el).css("backgroundColor",color);
        });


    })




    function login() {
        $.ajax({
//几个参数需要注意一下
                type: "POST",//方法类型
                dataType: "json",//预期服务器返回的数据类型
                url: "<?php echo url("admin/admin/seting") ?>" ,//url
            data: $('#form').serialize(),
            success: function (result) {
            console.log(result);//打印服务端返回的数据(调试用)
            if (result.code == 0) {
                alert(result.msg);
            }else{
                alert(result.msg);
            }

        }
    });
    }

    $(document).ready(function(){
        $("#memcache").click(function(){
            $("#rediss").show();
        });
    });
    $(document).ready(function(){
        $("#redis").click(function(){
            $("#rediss").show();
        });
    });
    $(document).ready(function(){
        $("#file").click(function(){
            $("#rediss").hide();
            // $("#rediss").slideToggle();
        });
    });
</script>