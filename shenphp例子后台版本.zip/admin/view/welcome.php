<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">控制台</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">
        <div style="text-align:center; line-height:300%; font-size:24px;">系统名：神奇cms<br>
            <p style="color:#f00;">版权所有：神奇cms</p>
            <p style="color:#f00;">官方网站：神奇cms</p>
            <p style="color:#f00;">最后更新：2020/03/13</p>
            <p style="color:#f00;">版本类型：神奇cms</p>
            <p style="color:#f00;">版本号：神奇cms</p>
            <p style="color:#f00;">神奇导航交流群①：334313432</p>
            <p style="color:#f00;">请勿用于违法用途 以及商业用途等</p>
            <p style="color:#f00;">下版本预计功能：请看官方</p>
        </div>
    </div>
    <!--内容页结束-->

</div><!-- /.page-content -->

<script src="/static/js/jquery.min.js"></script>
<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />