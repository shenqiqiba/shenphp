<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">数据库助手</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->
    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">
        <!--内容开始-->
        <div class="row">
            <div class="widget-box">
                <div class="widget-header">
                    <h4 class="widget-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">数据库助手</font></font></h4>

                    <div class="widget-toolbar">
                        <a href="#" data-action="collapse"><i class="ace-icon fa fa-chevron-up"></i></a>
                        <a href="#" data-action="close"><i class="ace-icon fa fa-times"></i></a>
                    </div>
                </div>

                <div class="widget-body" style="display: block;">
                    <div class="widget-main" style="margin-top: -1px;clear: both;overflow: hidden;">
                        <!--添加开始-->

                        <div class="col-xs-12">
                            <!-- PAGE CONTENT BEGINS -->
                            <form class="form-horizontal" id="form" role="form">
                                <input type="hidden" name="adduser" value="{:session('user_name')}" />
                                <div class="form-group">
                                    <label class="col-sm-2 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> SQL语句 </font></font></label>
                                    <div class="col-sm-9"><input type="text" id="form-field-1" value="" name="sql" placeholder="SQL语句" class="col-xs-10 col-sm-5">

                                    </div>
                                </div>

                                <div class="form-group">
                                    <label style="padding-left: 12%;"  for="form-field-1">
                                        1: 列出所有数据  select * from sq_article<br>
                                        2: 删除所有数据（id不还原为0）  delete  from sq_article/sq_type/sq_file 三个表各执行一次但不会删除附件数据和tag等<br>
                                        3: 清空所有数据（id还原为从0开始） TRUNCATE sq_article/sq_type/sq_file 三个表各执行一次 但不会删除附件数据和tag等<br>
                                        4: 清空会员数据 TRUNCATE sq_user <br>
                                        8: 批量设置会员到期时间 UPDATE sq_user SET user_vipendtime ='1923278400'  其中1923278400为时间戳<br>
                                        9: 批量设置会员qq：UPDATE sq_user SET user_qq ='999' 其中999为需要设置的qq<br>
                                        <span style="color:#F00">(请谨慎操作，以免造成数据错误！)</span><br>
                                        <div id="sqhtml" class="sqhtml"></div>
                                    </label>
                                </div>

                                <div class="clearfix form-actions">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button class="btn btn-info" type="button" onclick="tijiao()"><i class="ace-icon fa fa-check bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">运行</font></font></button>
                                        &nbsp; &nbsp; &nbsp;
                                        <button class="btn" type="reset"><i class="ace-icon fa fa-undo bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">重置</font></font></button>
                                    </div>
                                </div>

                            </form>

                            <div class="space-4"></div>
                            <form id="form2" class="form-horizontal">
                                <input type="hidden" name="adduser" value="{:session('user_name')}" />

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 生成数量 </font></font></label>
                                    <div class="col-sm-9"><input type="text" id="form-field-1" value="10" name="num" placeholder="用户名" class="col-xs-10 col-sm-5"></textarea></div>
                                </div>


                                <div class="space-4"></div>
                                <div class="clearfix form-actions">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button class="btn btn-info" type="button" onclick="tijiao2()"><i class="ace-icon fa fa-check bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">数据批量替换(暂未开发)</font></font></button>
                                        &nbsp; &nbsp; &nbsp;
                                        <button class="btn" type="reset"><i class="ace-icon fa fa-undo bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">重置</font></font></button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <!--添加结束-->
                    </div>
                </div>
            </div>




        </div>
        <!--内容结束-->
        <script src="/static/js/jquery.min.js"></script>
        <link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
        <!-- page specific plugin styles -->
        <!-- text fonts -->
        <link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
        <!-- ace styles -->
        <link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
        <!-- ace settings handler -->

        <script type="text/javascript">
            function tijiao() {
                $.ajax({
//几个参数需要注意一下
                    type: "POST",//方法类型
                    dataType: "json",//预期服务器返回的数据类型
                    url: "<?php echo url('admin/beifen/sqlzhushou') ?>" ,//url
                    data: $('#form').serialize(),
                    success: function (result) {
                        console.log(result);//打印服务端返回的数据(调试用)
                        if (result.code == 0) {
                            alert(result.msg);
                            $('#sqhtml').html(result.text);
                            //alert(result.text);
                            $('#sqhtml').append(result.msg);
                            // document.getElementById("sqhtml").innerHTML = JSON.parse(result.msg);
                        }else{
                            alert(result.msg);
                        }

                    }
                });
            }

            function tijiao2() {
                $.ajax({
//几个参数需要注意一下
                    type: "POST",//方法类型
                    dataType: "json",//预期服务器返回的数据类型
                    url: "<?php echo url('admin/beifen/sqlzhushou2') ?>" ,//url
                    data: $('#form2').serialize(),
                    success: function (result) {
                        console.log(result);//打印服务端返回的数据(调试用)
                        if (result.code == 1) {
                            alert(result.msg);
                        }else{
                            alert(result.msg);
                        }

                    }
                });
            }

        </script>
