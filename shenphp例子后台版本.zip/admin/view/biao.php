<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">表管理</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">

        <!--内容开始-->

        <div class="row">

            <div class="col-xs-12">
                <div class="clearfix">
                    <button type="button" tooltip="添加字段" class="btn btn-sm btn-primary" onclick="javascript:window.location.href = '<?php echo url('admin/beifen/beifen') ?>'"> <i class="fa fa-plus"></i> 查看备份</button>

                    <button type="button" tooltip="CSV" class="btn btn-sm btn-primary btn-addon" onclick="dccsv()"> <i class="fa fa-download"></i> CSV</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dcxls()"> <i class="fa fa-pencil-square-o"></i> exvel</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dccsv()"> <i class="fa fa-print"></i> 打印</button>
                    共有<?php echo count($list); ?>条数据

                </div>
                <form method="post" id='form'>
                    <table id="simple-table" class="table  table-bordered table-hover">
                        <thead>
                        <tr>
                            <th class="center">
                                <label class="pos-rel"><input type="checkbox" id="shenqi" class="ace"><span class="lbl"></span></label>
                            </th>
                            <th>序号</th>
                            <th>表名</th>
                            <th>引擎</th>
                            <th>大小</th>
                            <th>字符集</th>
                            <th>说明</th>
                            <th>操作</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php
                        foreach($list as $k=>$v):
                            if($v!=='.' && $v!=='..'):
                                ?>
                                <tr>
                                    <td class="center"><label class="pos-rel"><input type="checkbox" name="table[]" value="<?php echo $v['Name']; ?>" class="ace"><span class="lbl"></span></label></td>
                                    <td><?php echo $k+1; ?></td>
                                    <td><?php echo $v['Name']; ?></td>
                                    <td><?php echo $v['Engine']; ?></td>
                                    <td><?php echo getsize($v['Data_length']); ?></td>
                                    <td><?php echo $v['Collation']; ?></td>
                                    <td><?php echo $v['Comment']; ?></td>



                                    <td>
                                        <div class="hidden-sm hidden-xs btn-group">
                                            <a href="<?php echo url('admin/beifen/ziduan',['table_name'=>$v['Name']]) ?> "  class="btn btn-xs btn-primary">管理字段</a>
                                            <a href="javascript:;" onclick="caozuo('<?php echo $v['Name']; ?>',1)" class="btn btn-xs btn-warning">修复</a>
                                            <a href="javascript:;" onclick="caozuo('<?php echo $v['Name']; ?>',2)" class="btn btn-xs btn-warning">优化</a>
                                            <a href="javascript:;" onclick="caozuo('<?php echo $v['Name']; ?>',3)" class="btn btn-xs btn-danger"><i class="ace-icon fa fa-trash-o bigger-120"></i>删除</a>
                                        </div>
                                    </td>

                                </tr>
                            <?php endif; endforeach;?>





                        </tbody>
                    </table>
                </form>

            </div><!-- /.span -->
        </div>
        <!--保存按钮-->

        <!--内容页-->
        <div class="page-content">
            <!--内容开始-->
            <div class="row">
                <div class="widget-box">
                    <div class="widget-header">
                        <h4 class="widget-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">添加表</font></font></h4>

                        <div class="widget-toolbar">
                            <a href="#" data-action="collapse"><i class="ace-icon fa fa-chevron-up"></i></a>
                            <a href="#" data-action="close"><i class="ace-icon fa fa-times"></i></a>
                        </div>
                    </div>

                    <div class="widget-body col-xs-6" style="display: block;">
                        <div class="widget-main" style="margin-top: -1px;clear: both;overflow: hidden;">
                            <!--添加开始-->

                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->
                                <form class="form-horizontal" id="formadd" role="form">
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 表名 </font></font></label>
                                        <div class="col-sm-9"><input type="text" id="form-field-1" name="table" placeholder="表名 推荐sq_开头" value="sq_" class="col-xs-10 col-sm-5"></div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">说明/备注</font></font></label>
                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1" name="comment" placeholder="备注" value="备注" class="col-xs-10 col-sm-5">

                                        </div>
                                    </div>



                                    <div class="space-4"></div>

                                    <div class="clearfix form-actions col-md-8">
                                        <div class="col-md-offset-3 col-md-6">
                                            <button class="btn btn-info" type="button" onclick="tijiao()"><i class="ace-icon fa fa-check bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">提交</font></font></button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <!--添加结束-->
                        </div>
                    </div>
                </div>
            </div>
            <!--内容结束-->
            <!--内容结束-->
        </div>
        <!--内容页结束-->

    </div><!-- /.page-content -->


    <link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
    <!-- page specific plugin styles -->
    <!-- text fonts -->
    <link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
    <!-- ace styles -->
    <link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
    <!-- ace settings handler -->
    <script src="/static/js/jquery.min.js"></script>

    <script type="text/javascript">

        function tijiao() {
            $.ajax({
//几个参数需要注意一下
                type: "POST",//方法类型
                dataType: "json",//预期服务器返回的数据类型
                url: "<?php echo url('admin/beifen/biaoadd') ?>" ,//url
                data: $('#formadd').serialize(),
                success: function (result) {
                    console.log(result);//打印服务端返回的数据(调试用)
                    if (result.code == 0) {
                        alert(result.msg);
                        //window.location.href="/admin/table.php";
                        location.reload();
                    }else{
                        alert(result.msg);
                    }

                }
            });
        }




        /*用户-删除*/
        function caozuo(beifenname,type){
            if(window.confirm('确认要操作吗？操作不可逆'))
            {
//发异步删除数据
                $.ajax({
                    url: "<?php echo url('admin/beifen/biaocaozuo') ?>" ,
                    data: {'table':beifenname,'type':type} ,
                    type: "post" ,
                    dataType:'json',
                    success:function(data){
                        if(data.code==0){
                            //$(obj).parents("tr").remove();
                            alert(data.msg);
                            location.reload();
                        }else{
                            alert(data.msg);
                        }}
                })
                alert(data.msg);
            }
        }




        jQuery('#simple-table #shenqi').change(function () {
            var set = $(".ace");
            var checked = jQuery(this).is(":checked");
            jQuery(set).each(function () {
                if (checked) {
                    $(this).prop("checked", true);
                    $(this).parents('tr').addClass("active");
                } else {
                    $(this).prop("checked", false);
                    $(this).parents('tr').removeClass("active");
                }
            });

        });

        //导出
        function dccsv(){
            var $trs = $("#simple-table").find("tr");
            var str = "";
            for (var i = 0; i < $trs.length; i++) {
                var $tds = $trs.eq(i).find("td,th");
                for (var j = 0; j < $tds.length; j++) {
                    var strt=$tds.eq(j).text();

                    strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                    strt = strt.replace(/[ ]/g,"");
                    strt = strt.replace(/[\r\n]/g,"");
                    if(strt!='' || strt!='编辑删除')
                    {str += strt + ",";}
                }
                str += "\n";
            }

            var aaaa = "data:text/csv;charset=utf-8,\ufeff" + str;
            console.log(str);
            var link = document.createElement("a");
            link.setAttribute("href", aaaa);
            var date=new Date().getTime();
            var filename = new Date(date).toLocaleDateString();
            link.setAttribute("download", filename + ".csv");
            link.click();
        }

        function dcxls(){
            var $trs = $("#simple-table").find("tr");
            var str = "";
            for (var i = 0; i < $trs.length; i++) {
                var $tds = $trs.eq(i).find("td,th");
                for (var j = 0; j < $tds.length; j++) {
                    var strt=$tds.eq(j).text();

                    strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                    strt = strt.replace(/[ ]/g,"");
                    strt = strt.replace(/[\r\n]/g,"");
                    if(strt!='' || strt!='编辑删除')
                    {str += strt + ",";}
                }
                str += "\n";
            }

            var aaaa = "data:text/xls;charset=utf-8,\ufeff" + str;
            console.log(str);
            var link = document.createElement("a");
            link.setAttribute("href", aaaa);
            var date=new Date().getTime();
            var filename = new Date(date).toLocaleDateString();
            link.setAttribute("download", filename + ".xls");
            link.click();
        }
    </script>
