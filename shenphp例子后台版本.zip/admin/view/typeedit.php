<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li><a href="{:url('type/typelist')}">分类列表</a></li>
            <li class="active">编辑分类</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->
    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">
        <!--内容开始-->
        <div class="row">
            <div class="widget-box">
                <div class="widget-header">
                    <h4 class="widget-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">编辑分类</font></font></h4>

                    <div class="widget-toolbar">
                        <a href="#" data-action="collapse"><i class="ace-icon fa fa-chevron-up"></i></a>
                        <a href="#" data-action="close"><i class="ace-icon fa fa-times"></i></a>
                    </div>
                </div>

                <div class="widget-body" style="display: block;">
                    <div class="widget-main" style="margin-top: -1px;clear: both;overflow: hidden;">
                        <!--添加开始-->

                        <div class="col-xs-12">
                            <!-- PAGE CONTENT BEGINS -->
                            <form class="form-horizontal" id="form" role="form">
                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 分类名 </font></font></label>
                                    <div class="col-sm-9"><input type="text" id="form-field-1" value="<?php echo $type['type_name'] ?>" name="type_name" placeholder="分类名" class="col-xs-10 col-sm-5">
                                        <input type="hidden" name="type_id" value="<?php echo $type['type_id'] ?>" />
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 别名 </font></font></label>
                                    <div class="col-sm-9"><input type="text" id="form-field-1" value="<?php echo $type['type_tname'] ?>" name="type_tname" placeholder="别名" class="col-xs-10 col-sm-5"></div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 排序 </font></font></label>
                                    <div class="col-sm-9"><input type="text" id="form-field-1" value="<?php echo $type['type_sort'] ?>" name="type_sort" placeholder="排序" class="col-xs-10 col-sm-2"></div>
                                </div>


                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 模板 </font></font></label>
                                    <div class="col-sm-9"><input type="text" id="form-field-1" value="<?php echo $type['type_template'] ?>" name="type_template" placeholder="模板留空就使用默认" class="col-xs-10 col-sm-2"></div>
                                </div>


                                <div class="form-group">
                                    <label for="group_id" class="col-sm-3 control-label no-padding-right">分类</label>
                                    <div class="col-sm-3">
                                        <select name="type_pid" style="width: 100%;">
                                            <option selected  value="0">顶级分类</option>
                                            <?php foreach($list as $k=>$v): ?>
                                                <?php if($type['type_id']==$v['type_id']): else:  ?>
                                                    <option <?php if($type['type_pid']==$v['type_id']){ echo"selected"; }  ?>  value="<?php echo $v['type_id']; ?>"><?php if($v['level']!==0){ echo '|';} echo str_repeat('-', $v['level']*4); echo $v['type_name']; ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; ?>

                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 关键字 </font></font></label>
                                    <div class="col-sm-9"><input type="text" id="form-field-1" value="<?php echo $type['type_key'] ?>" name="type_key" placeholder="关键字英文逗号隔开" class="col-xs-10 col-sm-6"></div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 描述 </font></font></label>
                                    <div class="col-sm-9">
                                        <textarea class="col-xs-10 col-sm-6" id="form-field" name="type_des" placeholder="" ><?php echo $type['type_des'] ?></textarea>
                                    </div>
                                </div>



                                <div class="space-4"></div>





                                <div class="clearfix">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button class="btn btn-info" type="button" onclick="tijiao()"><i class="ace-icon fa fa-check bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">提交</font></font></button>
                                        &nbsp; &nbsp; &nbsp;
                                        <button class="btn" type="reset"><i class="ace-icon fa fa-undo bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">重置</font></font></button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <!--添加结束-->
                    </div>
                </div>
            </div>




        </div>
        <link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
        <!-- page specific plugin styles -->
        <!-- text fonts -->
        <link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
        <!-- ace styles -->
        <link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
        <!-- ace settings handler -->
        <script src="/static/js/jquery.min.js"></script>
        <script type="text/javascript">
            function tijiao() {
                $.ajax({
//几个参数需要注意一下
                    type: "POST",//方法类型
                    dataType: "json",//预期服务器返回的数据类型
                    url: '<?php echo url("admin/type/typeedit") ?>' ,//url
                    data: $('#form').serialize(),
                    success: function (result) {
                        console.log(result);//打印服务端返回的数据(调试用)
                        if (result.code == 0) {
                            alert(result.msg);
                            window.location.href='<?php echo url("admin/type/typelist") ?>';
                        }else{
                            alert(result.msg);
                        }

                    }
                });
            }



        </script>