<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">路由编辑</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->
    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">
        <!--内容开始-->
        <div class="row">
            <div class="widget-box">
                <div class="widget-header">
                    <h4 class="widget-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">路由编辑</font></font></h4>

                    <div class="widget-toolbar">
                        <a href="#" data-action="collapse"><i class="ace-icon fa fa-chevron-up"></i></a>
                        <a href="#" data-action="close"><i class="ace-icon fa fa-times"></i></a>
                    </div>
                </div>

                <div class="widget-body" style="display: block;">
                    <div class="widget-main" style="margin-top: -1px;clear: both;overflow: hidden;">
                        <!--添加开始-->

                        <div class="col-xs-12">
                            <!-- PAGE CONTENT BEGINS -->
                            <form class="form-horizontal" id="form" role="form">
                                <div class="form-group">

                                    <div class="col-sm-12">
                                        <textarea name="html" class="form-control" style="height: 70%"><?php echo $route ?></textarea>
                                    </div>
                                </div>



                                <div class="clearfix form-actions">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button class="btn btn-info" type="button" onclick="tijiao()"><i class="ace-icon fa fa-check bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">提交</font></font></button>
                                        &nbsp; &nbsp; &nbsp;
                                        <button class="btn" type="reset"><i class="ace-icon fa fa-undo bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">重置</font></font></button>
                                    </div>
                                </div>

                            </form>

                            <div class="space-4"></div>

                        </div>

                        <!--添加结束-->
                    </div>
                </div>
            </div>




        </div>
        <!--内容结束-->
        <link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
        <!-- page specific plugin styles -->
        <!-- text fonts -->
        <link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
        <!-- ace styles -->
        <link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
        <!-- ace settings handler -->
        <script src="/static/js/jquery.min.js"></script>

        <script type="text/javascript">
            function tijiao() {
                $.ajax({
//几个参数需要注意一下
                    type: "POST",//方法类型
                    dataType: "json",//预期服务器返回的数据类型
                    url: "<?php echo url('admin/kuozhan/luyou') ?>" ,//url
                    data: $('#form').serialize(),
                    success: function (result) {
                        console.log(result);//打印服务端返回的数据(调试用)
                        if (result.code == 0) {
                            alert(result.msg);
                        }else{
                            alert(result.msg);
                        }

                    }
                });
            }


        </script>