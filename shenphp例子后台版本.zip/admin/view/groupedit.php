<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li><a href="{:url('group/grouplist')}">用户组</a></li>
            <li class="active">编辑用户组</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->
    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">
        <!--内容开始-->
        <div class="row">
            <div class="widget-box">
                <div class="widget-header">
                    <h4 class="widget-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">编辑用户组</font></font></h4>

                    <div class="widget-toolbar">
                        <a href="#" data-action="collapse"><i class="ace-icon fa fa-chevron-up"></i></a>
                        <a href="#" data-action="close"><i class="ace-icon fa fa-times"></i></a>
                    </div>
                </div>

                <div class="widget-body" style="display: block;">
                    <div class="widget-main" style="margin-top: -1px;clear: both;overflow: hidden;">
                        <!--添加开始-->

                        <div class="col-xs-12">
                            <!-- PAGE CONTENT BEGINS -->
                            <form class="form-horizontal" id="form" role="form">

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 用户组名称 </font></font></label>
                                    <div class="col-sm-9">
                                        <input type="text" id="form-field-1" name="group_name" value="<?php echo $group['group_name'] ?>" placeholder="" class="col-xs-10 col-sm-5">
                                        <input type="hidden" name="group_id" value="<?php echo $group['group_id'] ?>" />
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 版块</font></font></label>
                                    <div class="col-sm-9">
                                        <div class="checkbox">

                                            <?php foreach($typelist as$k=>$v): ?>
                                                <label>

                                                    <input name="group_type[]" type="checkbox" class="ace" <?php if(strpos($group['group_type'],",".$v['type_id'].",")!==false):echo 'checked'; endif;  ?>  value="<?php echo $v['type_id']; ?>"> <span class="lbl"><?php echo $v['type_name']; ?></span>
                                                </label>
                                            <?php endforeach;?>


                                            <label>
                                                <input type="button" class="lbl"  onclick="opcheckboxed('group_type[]', 'checkall')" value="全选">
                                                <input type="button" class="lbl"  onclick="opcheckboxed('group_type[]', 'uncheckall')" value="取消全选">
                                            </label>

                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 用户组页面</font></font></label>
                                    <div class="col-sm-9">
                                        <div class="checkbox">

                                            <label>
                                                <input name="group_auth[]" type="checkbox" class="ace" value="1" <?php if(strpos($group['group_auth'],"1,")!==false):echo 'checked'; endif;  ?>> <span class="lbl">列表页</span>
                                            </label>
                                            <label>
                                                <input name="group_auth[]" type="checkbox" class="ace"  value="2" <?php if(strpos($group['group_auth'],"2,")!==false):echo 'checked'; endif;  ?>> <span class="lbl">内容页</span>
                                            </label>
                                            <label>
                                                <input name="group_auth[]" type="checkbox" class="ace"  value="3" <?php if(strpos($group['group_auth'],"3,")!==false):echo 'checked'; endif;  ?>> <span class="lbl">下载页</span>
                                            </label>

                                            <label>
                                                <input type="button" class="lbl"  onclick="opcheckboxed('group_auth[]', 'checkall')" value="全选">
                                                <input type="button" class="lbl"  onclick="opcheckboxed('group_auth[]', 'uncheckall')" value="取消全选">
                                            </label>

                                        </div>
                                    </div>
                                </div>

                                <div class="space-4"></div>





                                <div class="clearfix form-actions">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button class="btn btn-info" type="button" onclick="tijiao()"><i class="ace-icon fa fa-check bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">提交</font></font></button>
                                        &nbsp; &nbsp; &nbsp;
                                        <button class="btn" type="reset"><i class="ace-icon fa fa-undo bigger-110"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">重置</font></font></button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <!--添加结束-->
                    </div>
                </div>
            </div>




        </div>
        <!--内容结束-->
        <link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
        <!-- page specific plugin styles -->
        <!-- text fonts -->
        <link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
        <!-- ace styles -->
        <link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
        <!-- ace settings handler -->
        <script src="/static/js/jquery.min.js"></script>
        <script type="text/javascript">
            function opcheckboxed(objName, type){
                var objNameList=document.getElementsByName(objName);
                if(null!=objNameList){
                    for(var i=0;i<objNameList.length;i++){
                        if(objNameList[i].checked==true)
                        {
                            if(type != 'checkall') {  // 非全选
                                objNameList[i].checked=false;
                            }

                        } else {
                            if(type != 'uncheckall') {  // 非取消全选
                                objNameList[i].checked=true;
                            }
                        }
                    }
                }
            }

            function tijiao() {
                $.ajax({
//几个参数需要注意一下
                    type: "POST",//方法类型
                    dataType: "json",//预期服务器返回的数据类型
                    url: "<?php echo url('admin/group/groupedit') ?>" ,//url
                    data: $('#form').serialize(),
                    success: function (result) {
                        console.log(result);//打印服务端返回的数据(调试用)
                        if (result.code == 0) {
                            alert(result.msg);
                            window.location.href="<?php echo url('admin/group/grouplist') ?>";
                        }else{
                            alert(result.msg);
                        }

                    }
                });
            }



        </script>