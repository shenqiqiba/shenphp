<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">文件列表</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">

        <!--内容开始-->

        <div class="row">

            <div class="col-xs-12">
                <div class="clearfix">
                    <button type="button" tooltip="添加" class="btn btn-sm btn-primary" onclick="javascript:window.location.href = '<?php echo url('admin/kuozhan/jingtaiadd') ?>'"> <i class="fa fa-plus"></i> 添加</button>
                    <!--button type="button" tooltip="批量删除" class="btn btn-sm btn-danger" onclick="pldel()"> <i class="fa fa-times"></i> 批量删除</button-->
                    <button type="button" tooltip="CSV" class="btn btn-sm btn-primary btn-addon" onclick="dccsv()"> <i class="fa fa-download"></i> CSV</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dcxls()"> <i class="fa fa-pencil-square-o"></i> exvel</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dccsv()"> <i class="fa fa-print"></i> 打印</button>
                    共有<?php echo count($wenjians) ?>条数据

                </div>
                <form method="post" id='form'>
                    <table id="simple-table" class="table  table-bordered table-hover">
                        <thead>
                        <tr>

                            <th >序号</th>
                            <th>附件地址</th>

                            <th>标题</th>
                            <th>操作</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php foreach($wenjians as $k=>$v):
                        if($v!=='' && $v!=='.' && $v!=='..'):
                        ?>

                        <tr>


                            <td><?php echo $k-1 ?></td>

                            <td><a href="/html/zs/<?php echo $v ?>" target="_blank"><?php echo $v ?></a></td>
                            <td ><?php echo $v ?></td>
                            <td>
                                <div class="hidden-sm hidden-xs btn-group">

                                    <a href="<?php echo url('admin/kuozhan/jingtaiedit',array('name'=>$v)) ?>" class="btn btn-xs btn-info" title="Show Details">编辑</span></a>
                                    <a href="javascript:;" onclick="del(this,'<?php echo $v ?>')" class="btn btn-xs btn-danger"><i class="ace-icon fa fa-trash-o bigger-120"></i>删除</a>
                                </div>
                            </td>

                        </tr>
                       <?php endif; endforeach; ?>





                        </tbody>
                    </table>
                </form>

            </div><!-- /.span -->
        </div>
        <!--保存按钮-->


        <!--内容结束-->
    </div>
    <!--内容页结束-->

</div><!-- /.page-content -->

<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
<!-- ace settings handler -->
<script src="/static/js/jquery.min.js"></script>
<script type="text/javascript">

    function del(obj,name){
        if(window.confirm('确认要删除吗？'))
        {
//发异步删除数据
            $.ajax({
                url: "<?php echo url('admin/kuozhan/jingtaidel') ?>" ,
                data: {'name':name} ,
                type: "post" ,
                dataType:'json',
                success:function(data){
                    if(data.code==0){
                        $(obj).parents("tr").remove();
                        alert(data.msg);
                        location.reload();
                    }else{
                        alert(data.msg);
                    }}
            })
            alert(data.msg);
        }
    }



    jQuery('#simple-table #shenqi').change(function () {
        var set = $(".ace");
        var checked = jQuery(this).is(":checked");
        jQuery(set).each(function () {
            if (checked) {
                $(this).prop("checked", true);
                $(this).parents('tr').addClass("active");
            } else {
                $(this).prop("checked", false);
                $(this).parents('tr').removeClass("active");
            }
        });

    });

    //导出
    function dccsv(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/csv;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".csv");
        link.click();
    }

    function dcxls(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/xls;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".xls");
        link.click();
    }
</script>
