
</div>
<!--内容区域结束-->
</div><!-- /.main-content -->

<div class="footer">
    <div class="footer-inner">
        <div class="footer-content">
				<span class="bigger-120">
					<span class="blue bolder">神奇blog系统</span>
					Application &copy; 2020-2020
				</span>

            &nbsp; &nbsp;
				<span class="action-buttons">
					<a href="#"><i class="ace-icon fa fa-twitter-square light-blue bigger-150"></i></a>
					<a href="#"><i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i></a>
					<a href="#"><i class="ace-icon fa fa-rss-square orange bigger-150"></i></a>
				</span>
        </div>
    </div>
</div>

<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
    <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
</a>
</div><!-- /.main-container -->

<!-- basic scripts -->

<!--[if !IE]> -->
<script>
    function jumpurl(url){
        parent.document.getElementById('newpage').src=url;
    }
    function qqzx(){

    }
</script>
</body>
</html>