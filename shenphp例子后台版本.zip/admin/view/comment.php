<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">评论管理</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">

        <!--内容开始-->

        <div class="row">

            <div class="col-xs-12">
                <div class="clearfix">
                    <button type="button" tooltip="批量删除" class="btn btn-sm btn-danger" onclick="pldel()"> <i class="fa fa-times"></i> 批量删除</button>
                    <button type="button" tooltip="CSV" class="btn btn-sm btn-primary btn-addon" onclick="dccsv()"> <i class="fa fa-download"></i> CSV</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dcxls()"> <i class="fa fa-pencil-square-o"></i> exvel</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dccsv()"> <i class="fa fa-print"></i> 打印</button>
                    共有<?php echo count($list); ?>条数据

                </div>
                <form method="post" id='form'>
                    <table id="simple-table" class="table  table-bordered table-hover">
                        <thead>
                        <tr>
                            <th class="center">
                                <label class="pos-rel"><input type="checkbox" id="shenqi" class="ace"><span class="lbl"></span></label>
                            </th>
                            <th >内容</th>
                            <th>时间</th>
                            <th>评论者</th>
                            <th>所属文章</th>
                            <th>@他人</th>
                            <th>操作</th>
                        </tr>
                        </thead>

                        <tbody>

                        <?php foreach($list as $k=>$v):  ?>
                            <tr>
                                <td class="center"><label class="pos-rel"><input type="checkbox" name="comment_id[]" value="<?php echo $v['comment_id']; ?>" class="ace"><span class="lbl"></span></label></td>
                                <td><?php echo $v['comment_content']; ?></td>
                                <td><?php echo date('Y-m-d H:i:s',$v['comment_addtime']); ?></td>
                                <td><?php echo $v['comment_senduser']; ?></td>
                                <td><a href="#" target="_blank"><?php echo $v['article_id']; ?></a></td>
                                <td><?php echo $v['comment_getuser']; ?></td>

                                <td>

                                    <a href="javascript:;" onclick="shenhe(<?php echo $v['comment_id']; ?>,<?php echo $v['comment_status']; ?>)" <?php if($v['comment_status']==0){ echo 'class="btn btn-sm btn-success"'; }else{ echo 'class="btn btn-sm btn-grey"'; } ?>  ><?php if($v['comment_status']==0){ echo '已审核'; }else{ echo '待审核'; } ?></a>


                                    <a href="javascript:;" onclick="del(this,<?php echo $v['comment_id']; ?>)" class="btn btn-sm btn-danger">删除</a>
                                </td>
                            </tr>
                        <?php endforeach;?>

                        </tbody>
                    </table>
                </form>

            </div><!-- /.span -->
        </div>
        <!--保存按钮-->
        <div align="center">
            <?php echo $page ; ?>
        </div>

        <!--内容结束-->
    </div>
    <!--内容页结束-->

</div><!-- /.page-content -->
<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
<!-- ace settings handler -->
<script src="/static/js/jquery.min.js"></script>

<script type="text/javascript">
    function pldel()
    {
        if(window.confirm('确认要删除吗？')){
            var shuju=$('#form').serialize();
            $.ajax({
                //几个参数需要注意一下
                type: "POST",//方法类型
                dataType: "json",//预期服务器返回的数据类型
                url: "<?php echo url('admin/comment/commentdel') ?>" ,//url
                data:shuju,
                success: function (result) {
                    console.log(result);//打印服务端返回的数据(调试用)
                    if (result.code == 0) {
                        alert(result.msg);
                        window.location.reload();
                    }else{
                        alert(result.msg);
                        //window.location.reload();//false
                    }
                }
            });}
    }

    function del(obj,id) {
        if (window.confirm('确认要删除吗？')) {
            //发异步删除数据
            $.ajax({
                url: "<?php echo url('admin/comment/commentdel') ?>",
                data: {'comment_id': id},
                type: "post",
                dataType: 'json',
                success: function (data) {
                    if (data.code == 0) {
                        alert(data.msg);
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            });
            alert(data.msg);
        }
    }

    function shenhe($type_id,$status) {
        $.ajax({
//几个参数需要注意一下
            type: "POST",//方法类型
            dataType: "json",//预期服务器返回的数据类型
            url: "<?php echo url('admin/comment/commentshenhe') ?>",//url
            //data: $('#form').serialize(),
            data:{'comment_id':$type_id,'comment_status':$status},
            success: function (result) {
                console.log(result);//打印服务端返回的数据(调试用)
                if (result.code == 0) {
                    alert(result.msg);
                    location.reload();
                    //window.location.href="/admin/comment.php";
                }else{
                    alert(result.msg);
                }

            }
        });
    }

    //导出
    function dccsv(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/csv;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".csv");
        link.click();
    }
    jQuery('#simple-table #shenqi').change(function () {
        var set = $(".ace");
        var checked = jQuery(this).is(":checked");
        jQuery(set).each(function () {
            if (checked) {
                $(this).prop("checked", true);
                $(this).parents('tr').addClass("active");
            } else {
                $(this).prop("checked", false);
                $(this).parents('tr').removeClass("active");
            }
        });

    });
    function dcxls(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/xls;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".xls");
        link.click();
    }
</script>