<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
<!-- ace settings handler -->
<script src="/static/js/jquery.min.js"></script>

<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li><a href="{:url('kuozhan/api')}">API</a></li>
            <li class="active">API</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->
    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">
        <!--内容开始-->
        <div class="row">
            <div class="widget-box">
                <div class="widget-header">
                    <h4 class="widget-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">API</font></font></h4>

                    <div class="widget-toolbar">
                        <a href="#" data-action="collapse"><i class="ace-icon fa fa-chevron-up"></i></a>
                        <a href="#" data-action="close"><i class="ace-icon fa fa-times"></i></a>
                    </div>
                </div>

                <div class="widget-body" style="display: block;">
                    <div class="widget-main" style="margin-top: -1px;clear: both;overflow: hidden;">
                        <!--添加开始-->
                        <div class="col-xs-12">
                            <div class="timeline-item clearfix">
                                <div class="timeline-info"> </div>


                                <div class="col-xs-12">
                                    <?php foreach($typelist as $k=>$v): ?>
                                        <p><?php echo $v['type_name']; ?>-----<?php echo $v['type_id']; ?></p>
                                    <?php endforeach; ?>
                                </div>

                                <div class="col-xs-12">
                                    您的API密码为(网站配置中修改)：<b><?php echo shenphp\lib\Config::get('shenqi','apipw');  ?></b>
                                </div>



                            </div>
                        </div>
                        <!--添加结束-->
                    </div>
                </div>
            </div>


        </div>
        <!--内容结束-->