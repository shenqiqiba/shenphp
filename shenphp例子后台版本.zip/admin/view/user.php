<div class="main-content-inner">
    <!--内容页顶部-->
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li><i class="ace-icon fa fa-home home-icon"></i><a href="{:url('admin/index')}">首页</a></li>
            <li class="active">会员列表</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
						<span class="input-icon">
							<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
							<i class="ace-icon fa fa-search nav-search-icon"></i>
						</span>
            </form>
        </div><!-- /.nav-search -->

    </div>
    <!--内容页顶部结束-->
    <!--内容页-->
    <div class="page-content">

        <!--内容开始-->

        <div class="row">

            <div class="col-xs-12">
                <div class="clearfix">
                    <button type="button" tooltip="添加" class="btn btn-sm btn-primary" onclick="javascript:window.location.href = '<?php echo url('admin/user/useradd') ?>'"> <i class="fa fa-plus"></i> 添加</button>

                    <button type="button" tooltip="CSV" class="btn btn-sm btn-primary btn-addon" onclick="dccsv()"> <i class="fa fa-download"></i> CSV</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dcxls()"> <i class="fa fa-pencil-square-o"></i> exvel</button>
                    <button type="button" tooltip="exvel" class="btn btn-sm btn-success btn-addon" onclick="dccsv()"> <i class="fa fa-print"></i> 打印</button>
                    共有<?php echo count($list); ?>条数据

                </div>
                <form method="post" id='form'>
                    <table id="simple-table" class="table  table-bordered table-hover">
                        <thead>
                        <tr>
                            <th class="center">
                                <label class="pos-rel"><input type="checkbox" id="shenqi" class="ace"><span class="lbl"></span></label>
                            </th>
                            <th >用户</th>
                            <th>邮箱</th>
                            <th>积分</th>
                            <th>文章</th>
                            <th>用户组</th>
                            <th>注册时间</th>
                            <th>vip到期时间</th>
                            <th>操作</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php
                        foreach($list as $k=>$v):
                            ?>
                            <tr>
                                <td class="center"><label class="pos-rel"><input type="checkbox" name="user_id[]" value="<?php echo $v['user_id']; ?>" class="ace"><span class="lbl"></span></label></td>
                                <td><?php echo $v['user_name']; ?></td>
                                <td><?php echo $v['user_email']; ?></td>
                                <td><?php echo $v['user_jifen1']; ?></td>
                                <td>0</td>
                                <td><?php echo getgroupnames($v['group_id']); ?></td>
                                <td><?php echo date('Y-m-d H:i:s',$v['user_regtime']); ?></td>
                                <td><?php echo date('Y-m-d H:i:s',$v['user_vipendtime']); ?></td>
                                <td>
                                    <a href="javascript:void(0);" onclick="shenhe(<?php echo $v['user_id']; ?>,<?php echo $v['user_status']; ?>)"<?php if($v['user_status']==0){ echo 'class="btn btn-xs btn-success"'; }else{ echo 'class="btn btn-xs btn-danger"'; } ?>  ><?php if($v['user_status']==0){ echo '正常'; }else{ echo '已冻结'; } ?></a>

                                    <a href="<?php echo url('admin/user/useredit',['user_id'=>$v['user_id']]) ?>" class="btn btn-xs btn-info"><i class="ace-icon fa fa-pencil bigger-120"></i>编辑</a>
                                    <a href="javascript:;" onclick="del(this,'<?php echo $v['user_id']; ?>')" class="btn btn-xs btn-primary">删除</a> </tr>
                        <?php endforeach;?>

                        </tbody>
                    </table>
                </form>

            </div><!-- /.span -->
        </div>
        <!--保存按钮-->

        <div align="center">
            <?php echo $page; ?>
        </div>
        <!--内容结束-->
    </div>
    <!--内容页结束-->

</div><!-- /.page-content -->

<link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
<!-- page specific plugin styles -->
<!-- text fonts -->
<link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
<!-- ace styles -->
<link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
<!-- ace settings handler -->
<script src="/static/js/jquery.min.js"></script>
<script type="text/javascript">
    jQuery('#simple-table #shenqi').change(function () {
        var set = $(".ace");
        var checked = jQuery(this).is(":checked");
        jQuery(set).each(function () {
            if (checked) {
                $(this).prop("checked", true);
                $(this).parents('tr').addClass("active");
            } else {
                $(this).prop("checked", false);
                $(this).parents('tr').removeClass("active");
            }
        });

    });


    function shenhe($type_id,$status) {
        $.ajax({
//几个参数需要注意一下
            type: "POST",//方法类型
            dataType: "json",//预期服务器返回的数据类型
            url: "<?php echo url('admin/user/usershenhe') ?>",//url
            //data: $('#form').serialize(),
            data:{'user_id':$type_id,'user_status':$status},
            success: function (result) {
                console.log(result);//打印服务端返回的数据(调试用)
                if (result.code == 0) {
                    alert(result.msg);
                    location.reload();
                }else{
                    alert(result.msg);
                }

            }
        });
    }

    function del(obj,id) {
        if (window.confirm('确认要删除吗？')) {
            //发异步删除数据
            $.ajax({
                url: "<?php echo url('admin/user/userdel') ?>",
                data: {'user_id': id},
                type: "post",
                dataType: 'json',
                success: function (data) {
                    if (data.code == 0) {
                        alert(data.msg);
                        location.reload();
                    } else {
                        alert(data.msg);
                    }
                }
            })
            alert(data.msg);
        }
    }


    //导出
    function dccsv(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/csv;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".csv");
        link.click();
    }

    function dcxls(){
        var $trs = $("#simple-table").find("tr");
        var str = "";
        for (var i = 0; i < $trs.length; i++) {
            var $tds = $trs.eq(i).find("td,th");
            for (var j = 0; j < $tds.length; j++) {
                var strt=$tds.eq(j).text();

                strt=strt.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, "");
                strt = strt.replace(/[ ]/g,"");
                strt = strt.replace(/[\r\n]/g,"");
                if(strt!='' || strt!='编辑删除')
                {str += strt + ",";}
            }
            str += "\n";
        }

        var aaaa = "data:text/xls;charset=utf-8,\ufeff" + str;
        console.log(str);
        var link = document.createElement("a");
        link.setAttribute("href", aaaa);
        var date=new Date().getTime();
        var filename = new Date(date).toLocaleDateString();
        link.setAttribute("download", filename + ".xls");
        link.click();
    }
</script>