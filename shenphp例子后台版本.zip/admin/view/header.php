<!DOCTYPE html>
<html lang="ch-cn">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <title>神奇blog系统后台管理</title>
    <meta name="description" content="overview &amp; stats" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <!-- bootstrap & fontawesome -->
    <link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="/static/admin/font-awesome/4.5.0/css/font-awesome.min.css" />
    <!-- page specific plugin styles -->
    <!-- text fonts -->
    <link rel="stylesheet" href="/static/admin/css/fonts.googleapis.com.css" />
    <!-- ace styles -->
    <link rel="stylesheet" href="/static/admin/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />
    <!-- ace settings handler -->

    <!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/bootstrap/js/bootstrap.min.js"></script>
    <script src="/static/admin/js/ace-elements.min.js"></script>
    <script src="/static/admin/js/ace.min.js"></script>
    <?php addhook('admin_header'); ?>
</head>
<body class="no-skin" style="background: url(/static/images/bg.png) repeat #777;">
<div id="navbar" class="navbar navbar-default    ace-save-state">
    <div class="navbar-container ace-save-state" id="navbar-container">
        <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
            <span class="sr-only">侧边</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>

        <div class="navbar-header pull-left">
            <a href="{:url('admin/admin/index')}" class="navbar-brand"><small><i class="fa fa-leaf"></i>神奇blog系统</small>
            </a>
        </div>

        <div class="navbar-buttons navbar-header pull-right" role="navigation">
            <ul class="nav ace-nav">
                <!--顶部结束-->
                <li class="grey dropdown-modal"><a data-toggle="dropdown" class="dropdown-toggle" href="#">提醒(0)</a>
                </li>
                <li class="purple dropdown-modal"><a class="dropdown-toggle" href="<?php echo url('admin/admin/clearcache') ?>">清空缓存</a>
                </li>

                <li class="green dropdown-modal"><a href="/" target="blank">前台首页</a></li>

                <li class="light-blue dropdown-modal">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle"><img class="nav-user-photo" src="/static/admin/images/avatars/user.jpg" alt="Jason's Photo" /><span class="user-info"><small>你好,</small><?php echo  \shenphp\lib\Session::get('user_name')?></span><i class="ace-icon fa fa-caret-down"></i></a>

                    <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                        <li><a href="#"><i class="ace-icon fa fa-cog"></i>设置</a></li>
                        <li class="divider"></li>
                        <li><a href="{:url('admin/user/logout')}"><i class="ace-icon fa fa-power-off"></i>退出</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div><!-- /.navbar-container -->
</div>

<div class="main-container ace-save-state" id="main-container">
    <script type="text/javascript">
        try{ace.settings.loadState('main-container')}catch(e){}
    </script>
    <div id="sidebar" class="sidebar responsive  ace-save-state">
        <script type="text/javascript">
            try{ace.settings.loadState('sidebar')}catch(e){}
        </script>

        <ul class="nav nav-list">
            <li class="open"><a href="javascript:jumpurl('<?php echo url('admin/admin/welcome') ?>');"><i class="menu-icon fa fa-tachometer"></i><span class="menu-text">首页</span></a><b class="arrow"></b>
            </li>
            <li><a href="javascript:jumpurl('<?php echo url('admin/admin/seting') ?>');" ><i class="menu-icon fa fa-desktop"></i>网站配置</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/navi/navilist") ?>');" ><i class="menu-icon glyphicon glyphicon-cog"></i>导航配置</a></li>

            <li><a href="javascript:jumpurl('<?php echo url("admin/type/typelist") ?>');" ><i class="menu-icon fa fa-list"></i>分类管理</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/article/articlelistcaogao") ?>');" ><i class="menu-icon fa fa-book"></i>草稿</a></li>
            <!--li><a href="javascript:jumpurl('{:url("article/articlelisthtml")}');" ><i class="menu-icon fa fa-book"></i>页面管理</a></li-->
            <li><a href="javascript:jumpurl('<?php echo url("admin/article/articlelist") ?>');" ><i class="menu-icon fa fa-book"></i>文章管理</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/tag/taglist") ?>');" ><i class="menu-icon fa fa-tag"></i>标签管理</a></li>


            <li><a href="javascript:jumpurl('<?php echo url("admin/plugins/index") ?>');" ><i class="menu-icon fa fa-cogs"></i>插件管理</a></li>

            <li><a href="javascript:jumpurl('<?php echo url("admin/link/linklist") ?>');" ><i class="menu-icon fa fa-exchange"></i>友情链接</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/user/userlist") ?>');" ><i class="menu-icon glyphicon glyphicon-user"></i>会员管理</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/group/grouplist") ?>');" ><i class="menu-icon fa fa-users"></i>用户组管理</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/comment/commentlist") ?>');" ><i class="menu-icon fa fa-comment-o"></i>评论管理</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/yqm/yqmlist") ?>');" ><i class="menu-icon fa fa-key"></i>邀请码</a></li>
            <li><a href="javascript:jumpurl('<?php echo url("admin/file/filelist") ?>');" ><i class="menu-icon fa fa-folder-o"></i>文件管理</a></li>
            <li  >
                <a href="#" class="dropdown-toggle"><i class="menu-icon fa fa-hospital-o"></i><span class="menu-text">数据库管理</span><b class="arrow fa fa-angle-down"></b></a>
                <ul class="submenu nav-hide" >
                    <li><a href="javascript:jumpurl('<?php echo url("admin/beifen/beifen") ?>');" ><i class="menu-icon fa fa-caret-right"></i>备份管理</a></li>
                    <li><a href="javascript:jumpurl('<?php echo url("admin/beifen/biao") ?>');" ><i class="menu-icon fa fa-caret-right"></i>表管理</a></li>
                    <li class=""><a href="javascript:jumpurl('<?php echo url("admin/beifen/sqlzhushou") ?>');" ><i class="menu-icon fa fa-caret-right"></i>数据库助手</a><b class="arrow"></b></li>
                </ul>
            </li>
            <?php addhook('admin_sider'); ?>
            <li>
                <a href="#" class="dropdown-toggle"><i class="menu-icon fa fa-hospital-o"></i><span class="menu-text">扩展专区</span><b class="arrow fa fa-angle-down"></b></a>
                <ul class="submenu nav-hide" >
                    <?php addhook('admin_sider_kuozhan'); ?>
                    <li><a href="javascript:jumpurl('<?php echo url("admin/kuozhan/api") ?>');" ><i class="menu-icon fa fa-caret-right"></i>API管理</a></li>
                    <li><a href="javascript:jumpurl('<?php echo url("admin/kuozhan/muban") ?>');"><i class="menu-icon fa fa-caret-right"></i>模板管理</a></li>
                    <li><a href="javascript:jumpurl('<?php echo url("admin/kuozhan/jingtai") ?>');"><i class="menu-icon fa fa-caret-right"></i>静态管理</a></li>

                    <li><a href="javascript:jumpurl('<?php echo url("admin/kuozhan/luyou") ?>');"><i class="menu-icon fa fa-caret-right"></i>--路由设置</a></li>
                    <li><a href="javascript:jumpurl('<?php echo url("admin/soft/soft") ?>');"><i class="menu-icon fa fa-caret-right"></i>软件管理</a></li>
                    <li><a href="javascript:jumpurl('<?php echo url("admin/kuozhan/map") ?>');"><i class="menu-icon fa fa-caret-right"></i>地图生成</a></li>
                    <!--li><a href="javascript:void(0);" onclick="0();"><i class="menu-icon fa fa-caret-right"></i>扩展专用</a></li-->

                </ul>
            </li>



            <li><a href="javascript:jumpurl('<?php echo url("admin/admin/about") ?>');" ><i class="menu-icon fa fa-qrcode"></i>常见问题</a></li>
            <li><a href="http://shenqiyu.com" target="blank"><i class="menu-icon fa fa-share-square"></i>神奇导航官方</a></li>


        </ul><!-- /.nav-list -->

        <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
            <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
        </div>
    </div>

    <!--内容区域开始-->



